import { assert, it, describe, expect } from "vitest";

import { TEST_ACCESS_TOKEN, TEST_HUB_URL, TEST_USER } from "../test/consts";
import type { RepoId } from "../types/public";
import { insecureRandomString } from "../utils/insecureRandomString";
import { createRepo } from "./create-repo";
import { deleteRepo } from "./delete-repo";
import { downloadFile } from "./download-file";
import { uploadFile } from "./upload-file";

describe("uploadFile", () => {
	it("should upload a file", async () => {
		const repoName = `${TEST_USER}/TEST-${insecureRandomString()}`;
		const repo = { type: "model", name: repoName } satisfies RepoId;

		try {
			const result = await createRepo({
				accessToken: TEST_ACCESS_TOKEN,
				repo,
				hubUrl: TEST_HUB_URL,
			});

			expect(result).toEqual({
				repoUrl: `${TEST_HUB_URL}/${repoName}`,
				id: expect.any(String),
			});

			await uploadFile({
				accessToken: TEST_ACCESS_TOKEN,
				repo,
				file: { content: new Blob(["file1"]), path: "file1" },
				hubUrl: TEST_HUB_URL,
			});
			await uploadFile({
				accessToken: TEST_ACCESS_TOKEN,
				repo,
				file: new URL("https://huggingface.co/gpt2/raw/main/config.json"),
				hubUrl: TEST_HUB_URL,
			});

			let content = await downloadFile({
				repo,
				path: "file1",
				hubUrl: TEST_HUB_URL,
			});

			assert.strictEqual(await content?.text(), "file1");

			content = await downloadFile({
				repo,
				path: "config.json",
				hubUrl: TEST_HUB_URL,
			});

			assert.strictEqual(
				(await content?.text())?.trim(),
				`
{
  "activation_function": "gelu_new",
  "architectures": [
    "GPT2LMHeadModel"
  ],
  "attn_pdrop": 0.1,
  "bos_token_id": 50256,
  "embd_pdrop": 0.1,
  "eos_token_id": 50256,
  "initializer_range": 0.02,
  "layer_norm_epsilon": 1e-05,
  "model_type": "gpt2",
  "n_ctx": 1024,
  "n_embd": 768,
  "n_head": 12,
  "n_layer": 12,
  "n_positions": 1024,
  "resid_pdrop": 0.1,
  "summary_activation": null,
  "summary_first_dropout": 0.1,
  "summary_proj_to_labels": true,
  "summary_type": "cls_index",
  "summary_use_proj": true,
  "task_specific_params": {
    "text-generation": {
      "do_sample": true,
      "max_length": 50
    }
  },
  "vocab_size": 50257
}
      `.trim(),
			);
		} finally {
			await deleteRepo({
				repo,
				accessToken: TEST_ACCESS_TOKEN,
				hubUrl: TEST_HUB_URL,
			});
		}
	});

	it("should edit a file via an `edits` param", async () => {
		const repoName = `${TEST_USER}/TEST-${insecureRandomString()}`;
		const repo = { type: "model", name: repoName } satisfies RepoId;

		try {
			await createRepo({
				accessToken: TEST_ACCESS_TOKEN,
				repo,
				hubUrl: TEST_HUB_URL,
			});

			await uploadFile({
				accessToken: TEST_ACCESS_TOKEN,
				repo,
				file: { content: new Blob(["Hello, World!"]), path: "file1" },
				hubUrl: TEST_HUB_URL,
			});

			const original = await downloadFile({
				accessToken: TEST_ACCESS_TOKEN,
				repo,
				path: "file1",
				hubUrl: TEST_HUB_URL,
			});
			assert(original);

			await uploadFile({
				accessToken: TEST_ACCESS_TOKEN,
				repo,
				file: {
					path: "file1",
					originalContent: original,
					edits: [{ content: new Blob(["Beautiful "]), start: 7, end: 7 }],
				},
				hubUrl: TEST_HUB_URL,
			});

			const content = await downloadFile({
				repo,
				path: "file1",
				hubUrl: TEST_HUB_URL,
			});

			assert.strictEqual(await content?.text(), "Hello, Beautiful World!");
		} finally {
			await deleteRepo({
				repo,
				accessToken: TEST_ACCESS_TOKEN,
				hubUrl: TEST_HUB_URL,
			});
		}
	});
});
