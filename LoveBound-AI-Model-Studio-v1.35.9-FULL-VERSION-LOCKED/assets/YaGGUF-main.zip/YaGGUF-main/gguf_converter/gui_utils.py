"""
Utility functions for GGUF Converter GUI
"""

import streamlit as st
from pathlib import Path
import json
import re
import subprocess
import platform
import shutil
import logging
import tempfile
import os
from datetime import datetime
from typing import Dict, Optional, Tuple, Any, Callable, List
from colorama import Style
from .theme import THEME as theme

# Optional tkinter import for native file dialogs
try:
    import tkinter as tk
    from tkinter import filedialog
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False
    tk = None
    filedialog = None

__all__ = ['TKINTER_AVAILABLE', 'browse_folder', 'open_folder', 'strip_quotes',
           'save_config', 'load_config', 'get_default_config', 'make_config_saver', 'path_input_columns',
           'extract_repo_id_from_url', 'get_platform_path', 'CONFIG_FILE', 'HF_TOKEN_PATH',
           'STREAMLIT_CONFIG_DIR', 'HF_CACHE_DIR', 'show_processing_overlay',
           'launch_in_terminal', 'get_presets_path', 'load_presets', 'save_presets',
           'save_preset', 'delete_preset']


# Config file location
CONFIG_FILE = Path.home() / ".yagguf_config.json"

# HuggingFace token location (managed by huggingface_hub)
try:
    from huggingface_hub.constants import HF_TOKEN_PATH
except ImportError:
    # Fallback for older versions or if constant is moved
    HF_TOKEN_PATH = Path.home() / ".cache" / "huggingface" / "token"

# Streamlit config directory (contains config.toml, credentials.toml)
STREAMLIT_CONFIG_DIR = Path.home() / ".streamlit"

# HuggingFace cache directory (tokenizers, model metadata)
HF_CACHE_DIR = Path.home() / ".cache" / "huggingface"


def get_default_config() -> Dict[str, Any]:
    """Get default configuration"""
    return {
        # Sidebar settings
        "dev_mode": False,  # Show developer tools (Dev Tests button)
        "verbose": True,
        "use_imatrix": True,
        "num_threads": None,  # None = auto-detect
        "ignore_imatrix_warnings": False,  # Allow IQ quants without imatrix

        # Imatrix mode (on Convert & Quantize tab)
        "imatrix_mode": "generate",  # "generate", "generate_custom", or "reuse"
        "imatrix_generate_name": "",  # Custom filename for generated imatrix (empty = auto)
        "imatrix_reuse_path": "",  # Filename of imatrix to reuse from output directory

        # Imatrix Settings tab
        "imatrix_ctx_size": 512,
        "imatrix_chunks": 150,  # 100-200 recommended, 0 = all chunks
        "imatrix_collect_output_weight": False,
        "imatrix_calibration_file": "wiki.train.raw",  # Selected calibration file from the directory
        "imatrix_calibration_dir": "",  # Directory to scan for calibration files (empty = use default)
        "imatrix_from_chunk": 0,  # Skip first N chunks
        "imatrix_no_ppl": False,  # Disable perplexity
        "imatrix_parse_special": False,  # Parse special tokens
        "imatrix_output_frequency": 10,  # Save interval
        "imatrix_num_gpu_layers": 99,  # GPU layers (99 = offload all layers)
        "imatrix_stats_model": "",  # Model for statistics utility
        "imatrix_stats_path": "",  # Imatrix file for statistics
        "max_preview_lines": 1000,  # Maximum lines to show in calibration preview
        "preview_height": 700,  # Preview area height in pixels

        # Convert & Quantize tab
        "model_path": "",
        "output_dir": "",
        "intermediate_type": "F16",
        "pure_quantization": False,
        "file_mode": "Single files",
        "max_shard_size_gb": 2.0,
        "output_tensor_type": "Same as quant type (default)",
        "token_embedding_type": "Same as quant type (default)",

        # File handling options
        "overwrite_intermediates": True,  # Overwrite F32/F16/BF16 by default
        "overwrite_quants": True,  # Overwrite quantized formats by default

        # Quantization types - all stored in other_quants dict
        "other_quants": {
            "Q4_K_M": True,  # Default to Q4_K_M
        },

        # Saved states for unquantized format checkboxes (before they get disabled as intermediate)
        "unquantized_saved_states": {},

        # Download tab
        "repo_id": "",
        "download_dir": "",

        # Split/Merge tab
        "split_merge_input_dir": "",
        "split_merge_selected_file": None,
        "split_merge_output_dir": "",
        "split_merge_operation_mode": "Split",
        "split_merge_max_shard_size_gb": 2.0,
        "split_merge_copy_aux_files": True,

        # Custom intermediate (used when selecting existing intermediate file)
        "custom_intermediate_mode": None,
        "custom_intermediate_format": None,
        "custom_intermediate_path": None,
        "custom_intermediate_file_type": None,
        "custom_intermediate_saved_intermediate_type": None,

        # Imatrix statistics output
        "imatrix_stats_output_dir": "",

        # Custom binaries
        "use_custom_binaries": False,
        "custom_binaries_folder": "",

        # Custom conversion script
        "use_custom_conversion_script": False,
        "custom_llama_cpp_repo": "",

        # Run GGUF tab
        "run_model_path": "",
        "run_model_file": "",
        "run_mode": "llama-server",
        "run_auto_fit": True,
        "run_ngl": 99,
        "run_ctx": 4096,
        "run_flash_attn": False,
        "run_fit_target": 1024,
        "run_fit_ctx": 0,
        "run_cache_type_k": "f16",
        "run_cache_type_v": "f16",
        "run_port": 8080,
        "run_host": "127.0.0.1",
        "run_parallel": 1,
        "run_open_browser": True,
        "run_temp": 0.8,
        "run_top_k": 40,
        "run_top_p": 0.95,
        "run_min_p": 0.05,
        "run_presence_penalty": 0.0,
        "run_jinja": True,
        "run_reasoning": "off",

        "run_mmproj_enabled": True,

        # Bench-specific params
        "run_bench_n_prompt": 512,
        "run_bench_n_gen": 128,
        "run_bench_batch_size": 2048,
        "run_bench_ubatch_size": 512,
        "run_bench_repetitions": 5,
        "run_bench_threads": 0,
        "run_bench_output": "md",
        "run_bench_cache_type_k": "f16",
        "run_bench_cache_type_v": "f16",
        "run_bench_no_warmup": False,
        "run_bench_progress": False,

    }


def load_config() -> Dict[str, Any]:
    """Load configuration from file"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                saved_config = json.load(f)

            config = get_default_config()
            config.update(saved_config)
            return config
        except Exception as e:
            print(f"{theme['warning']}Warning: Could not load config: {e}{Style.RESET_ALL}", flush=True)
            return get_default_config()
    return get_default_config()


def save_config(config: Dict[str, Any]) -> None:
    """Save configuration to file"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        print(f"{theme['warning']}Warning: Could not save config: {e}{Style.RESET_ALL}", flush=True)


def make_config_saver(config: Dict[str, Any], config_key: str, session_key: str) -> Callable[[], None]:
    """Return an on_change callback that writes session_key's value into config and saves."""
    def save() -> None:
        if session_key in st.session_state:
            config[config_key] = st.session_state[session_key]
            save_config(config)
    return save


def reset_config() -> Dict[str, Any]:
    """Reset configuration to defaults"""
    config = get_default_config()
    save_config(config)
    return config


def launch_in_terminal(
    cmd_args: List[str],
    window_title: str = "YaGGUF",
    announce_title: Optional[str] = None,
    announce_subtitle: Optional[str] = None,
) -> bool:
    """
    Launch a command in a new terminal window.

    Args:
        cmd_args: List of command arguments
        window_title: Title for the new terminal window
        announce_title: Optional banner title (e.g. "llama-server")
        announce_subtitle: Optional banner subtitle (e.g. model filename)

    Returns:
        True on success, False on failure
    """
    import sys as _sys

    system = platform.system()
    project_root = Path(__file__).parent.parent
    python_exe = _sys.executable

    def _banner_text_lines() -> List[str]:
        """Return the centered text lines for the banner (no separators)."""
        if not announce_title:
            return []
        width = 80
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lines = [announce_title.upper().center(width)]
        if announce_subtitle:
            lines.append(announce_subtitle.center(width))
        lines.append(ts.center(width))
        return lines

    def _write_windows_banner(f: Any) -> None:
        """Write a Python one-liner to the .bat file that prints the banner via colorama.
        Uses single-quoted Python strings so they're safe inside cmd's outer "..." quoting.
        The run command is passed via env var to avoid quoting issues inside cmd's "..." context.
        """
        text_lines = _banner_text_lines()
        if not text_lines:
            return
        # Escape single quotes for Python single-quoted string literals (cmd passes \ through)
        def _sq(s: str) -> str:
            return s.replace("'", "\\'")
        py_parts = [
            "import os",
            "from colorama import init,Fore,Style",
            "init()",
            "c=Fore.WHITE+Style.DIM",
            "r=Style.RESET_ALL",
            "print(c+'='*80+r)",
        ]
        for line in text_lines:
            py_parts.append(f"print(c+'{_sq(line)}'+r)")
        py_parts += [
            "print(c+'='*80+r)",
            "cmd=os.environ.get('YAGGUF_CMD','')",
            "print(Fore.CYAN+cmd+r)",
            "print()",
        ]
        # set "VAR=value" is safe for paths: backslashes are literal, no " allowed in Windows paths
        f.write(f'set "YAGGUF_CMD={" ".join(cmd_args)}"\n')
        f.write(f'"{python_exe}" -c "{";".join(py_parts)}"\n')

    def _write_unix_banner(f: Any) -> None:
        """Write a Python heredoc block to a .sh file that prints the banner via colorama."""
        text_lines = _banner_text_lines()
        if not text_lines:
            return
        # Escape double quotes for Python double-quoted string literals inside the heredoc
        def _dq(s: str) -> str:
            return s.replace('"', '\\"')
        f.write(f'"{python_exe}" - << \'PYEOF\'\n')
        f.write('from colorama import init,Fore,Style\n')
        f.write('init()\n')
        f.write('c=Fore.WHITE+Style.DIM\n')
        f.write('r=Style.RESET_ALL\n')
        f.write('print(c+"="*80+r)\n')
        for line in text_lines:
            f.write(f'print(c+"{_dq(line)}"+r)\n')
        f.write('print(c+"="*80+r)\n')
        # repr() produces a safe Python literal for any path/arg content; heredoc has no shell expansion
        f.write(f'print(Fore.CYAN+{repr(" ".join(cmd_args))}+r)\n')
        f.write('print()\n')
        f.write('PYEOF\n')

    try:
        if system == "Windows":
            with tempfile.NamedTemporaryFile(mode='w', suffix='.bat', delete=False) as bat_file:
                bat_path = bat_file.name
                bat_file.write('@echo off\n')
                bat_file.write(f'cd /d "{project_root}"\n')
                _write_windows_banner(bat_file)
                cmd_line = ' '.join(f'"{arg}"' for arg in cmd_args)
                bat_file.write(f'{cmd_line}\n')
                bat_file.write('pause\n')
                bat_file.write('del "%~f0"\n')
            subprocess.Popen(
                f'cmd /c start "{window_title}" "{bat_path}"',
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            return True

        elif system == "Darwin":
            with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as sh_file:
                sh_path = sh_file.name
                sh_file.write('#!/bin/sh\n')
                _write_unix_banner(sh_file)
                cmd_str = " ".join(f'"{arg}"' for arg in cmd_args)
                sh_file.write(f'cd "{project_root}"\n')
                sh_file.write(f'{cmd_str}\n')
                sh_file.write("printf 'Press Enter to close...'; read _\n")
                sh_file.write(f'rm -f "{sh_path}"\n')
            os.chmod(sh_path, 0o755)
            subprocess.Popen([
                "osascript", "-e",
                f'tell app "Terminal" to do script "sh \\"{sh_path}\\""'
            ])
            return True

        else:
            # Linux: try various terminal emulators
            with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as sh_file:
                sh_path = sh_file.name
                sh_file.write('#!/bin/sh\n')
                _write_unix_banner(sh_file)
                cmd_str = " ".join(f'"{arg}"' if " " in arg else arg for arg in cmd_args)
                sh_file.write(f'cd "{project_root}"\n')
                sh_file.write(f'{cmd_str}\n')
                sh_file.write("printf 'Press Enter to close...'; read _\n")
                sh_file.write(f'rm -f "{sh_path}"\n')
            os.chmod(sh_path, 0o755)
            terminals = [
                ("x-terminal-emulator", ["-e", sh_path]),
                ("gnome-terminal", ["--", sh_path]),
                ("konsole", ["--", sh_path]),
                ("xfce4-terminal", ["-x", sh_path]),
                ("mate-terminal", ["-e", sh_path]),
                ("xterm", ["-e", sh_path]),
            ]
            for term, term_args in terminals:
                if shutil.which(term):
                    try:
                        subprocess.Popen([term] + term_args)
                        return True
                    except Exception as e:
                        logging.debug(f"Failed to launch terminal {term}: {e}")
                        continue
            return False

    except Exception as e:
        logging.error(f"Failed to launch terminal: {e}")
        return False


# Presets file location
PRESETS_FILE = Path.home() / ".yagguf_presets.json"


def get_presets_path() -> Path:
    """Get the path to the presets file."""
    return PRESETS_FILE


def load_presets() -> Dict[str, Any]:
    """Load presets from file, returning {} on missing or error."""
    if PRESETS_FILE.exists():
        try:
            with open(PRESETS_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"{theme['warning']}Warning: Could not load presets: {e}{Style.RESET_ALL}", flush=True)
    return {}


def save_presets(presets: Dict[str, Any]) -> None:
    """Write all presets to file."""
    try:
        with open(PRESETS_FILE, 'w') as f:
            json.dump(presets, f, indent=2)
    except Exception as e:
        print(f"{theme['warning']}Warning: Could not save presets: {e}{Style.RESET_ALL}", flush=True)


def save_preset(name: str, params: Dict[str, Any]) -> None:
    """Upsert a single preset by name."""
    presets = load_presets()
    presets[name] = params
    save_presets(presets)


def delete_preset(name: str) -> None:
    """Remove a preset by name."""
    presets = load_presets()
    if name in presets:
        del presets[name]
        save_presets(presets)


def strip_quotes(path_str: str | None) -> str:
    """
    Strip surrounding quotes from a path string (Windows "Copy as path" adds them)

    Args:
        path_str: Path string that may have quotes

    Returns:
        Path string without surrounding quotes
    """
    if not path_str:
        return ""
    return path_str.strip().strip('"').strip("'")


def get_platform_path(windows_path: str, unix_path: str) -> str:
    """
    Return platform-appropriate path string for placeholders

    Args:
        windows_path: Path string with Windows-style separators (backslashes)
        unix_path: Path string with Unix-style separators (forward slashes)

    Returns:
        The appropriate path string for the current platform

    Example:
        >>> placeholder = get_platform_path("C:\\Models\\output", "/home/user/Models/output")
    """
    return windows_path if platform.system() == "Windows" else unix_path


def open_folder(folder_path: str) -> None:
    """
    Open folder in file explorer (platform-specific)

    Args:
        folder_path: Path to folder to open
    """
    path = Path(strip_quotes(folder_path))

    if path.is_file():
        path = path.parent

    if not path.exists():
        raise FileNotFoundError(f"Path does not exist: {path}")

    system = platform.system()

    # Note: We don't use check=True because some file explorers (notably Windows explorer)
    # can return non-zero exit codes even when they successfully open the folder
    if system == "Windows":
        subprocess.run(["explorer", str(path.resolve())])
    elif system == "Darwin":  # macOS
        subprocess.run(["open", str(path.resolve())])
    else:  # Linux and others
        subprocess.run(["xdg-open", str(path.resolve())])


def get_current_version() -> str:
    """
    Get current version from __init__.py

    Returns:
        str: Version string or "unknown" if not found
    """
    try:
        from gguf_converter import __version__
        return __version__
    except Exception:
        return "unknown"


def check_git_updates_available() -> Dict[str, Any]:
    """
    Check if updates are available from GitHub Releases

    Supports authentication via GITHUB_TOKEN environment variable for private repos

    Returns:
        dict: Status info with keys 'status', 'message', 'latest_version'
    """
    try:
        import urllib.request

        # Get current version
        current_version = get_current_version()

        # Check GitHub Releases API for latest release (public repo, no auth needed)
        url = "https://api.github.com/repos/usrname0/YaGGUF/releases/latest"
        req = urllib.request.Request(url)
        req.add_header('Accept', 'application/vnd.github.v3+json')
        req.add_header('User-Agent', 'YaGGUF')

        with urllib.request.urlopen(req, timeout=10) as response:
            release_data = json.loads(response.read().decode())
            latest_tag = release_data.get('tag_name', '')

            if latest_tag:
                # Compare versions (remove 'v' prefix if present)
                current = current_version.lstrip('v')
                latest = latest_tag.lstrip('v')

                if latest != current:
                    return {
                        "status": "updates_available",
                        "message": f"New version available: **{latest_tag}** (current: {current_version})",
                        "latest_version": latest_tag
                    }
                else:
                    return {
                        "status": "up_to_date",
                        "message": "You are on the latest version of YaGGUF",
                        "latest_version": current_version
                    }
            else:
                return {
                    "status": "unknown",
                    "message": "No releases found",
                    "latest_version": None
                }
    except Exception as e:
        # Log the actual error to terminal for debugging
        from colorama import Style
        from .theme import THEME as theme
        print(f"{theme['warning']}Warning: Could not check for YaGGUF updates: {e}{Style.RESET_ALL}")
        return {
            "status": "unknown",
            "message": "Could not check for updates",
            "latest_version": None
        }


def path_input_columns() -> Tuple[List[Any], bool]:
    """
    Create column layout for path inputs with conditional browse button.

    Returns:
        tuple: (columns, has_browse_column)
            - columns: list of Streamlit column objects
            - has_browse_column: bool indicating if browse column exists

    Example:
        cols, has_browse = path_input_columns()
        with cols[0]:
            path = st.text_input("Path", ...)
        if has_browse:
            with cols[1]:
                if st.button("Browse", ...):
                    # browse logic
        with cols[-1]:  # Last column is always check button
            if st.button("Check Folder", ...):
                # check logic
    """
    if TKINTER_AVAILABLE:
        return st.columns([4, 1, 1]), True
    else:
        return st.columns([5, 1]), False


def browse_folder(initial_dir: Optional[str] = None) -> Optional[str]:
    """
    Open a native folder picker dialog

    Args:
        initial_dir: Initial directory to open (optional)

    Returns:
        str: Selected folder path or None if cancelled
    """
    if not TKINTER_AVAILABLE:
        st.error(
            "Folder browser requires tkinter.\n\n"
            "**On Linux**, install it with:\n"
            "- Ubuntu/Debian: `sudo apt install python3-tk`\n"
            "- Fedora/RHEL: `sudo dnf install python3-tkinter`\n"
            "- Arch: `sudo pacman -S tk`\n\n"
            "Then restart the GUI."
        )
        return None

    try:
        # Create a root window and hide it
        root = tk.Tk()
        root.withdraw()
        root.wm_attributes('-topmost', 1)

        # Open folder picker
        folder_path = filedialog.askdirectory(
            parent=root,
            initialdir=initial_dir,
            title="Select Folder"
        )

        root.destroy()
        # Convert to OS-native path separators (tkinter returns forward slashes on all platforms)
        if folder_path:
            return str(Path(folder_path))
        return None
    except Exception as e:
        print(f"{theme['error']}Error opening folder picker: {e}{Style.RESET_ALL}")
        return None


def get_binary_version(converter: Any) -> Dict[str, Any]:
    """
    Get version of llama.cpp binaries

    Args:
        converter: GGUFConverter instance

    Returns:
        dict: Binary version info
    """
    try:
        # Use llama_cpp_manager method to get version info
        version_info = converter.llama_cpp_manager.get_installed_version_info()

        if version_info['full_version']:
            return {
                "status": "ok",
                "version": version_info['full_version'],
                "message": "Binaries are installed"
            }

        # Check if binaries exist
        bin_dir = converter.llama_cpp_manager.bin_dir
        if bin_dir.exists() and any(bin_dir.iterdir()):
            return {
                "status": "ok",
                "version": "unknown",
                "message": "Binaries installed (version check unavailable)"
            }
        else:
            return {
                "status": "missing",
                "version": None,
                "message": "Binaries not installed. If something went wrong try 'Update Binaries - Recommended Version.'"
            }

    except Exception as e:
        return {
            "status": "error",
            "version": None,
            "message": f"Error checking binaries: {e}"
        }


def get_binary_version_from_path(binary_path: Optional[Path]) -> Optional[str]:
    """
    Get version from a specific binary path by running it with --version

    Args:
        binary_path: Path to the binary (e.g., llama-quantize or llama-imatrix)

    Returns:
        str: Version string or None if unable to get version
    """
    if binary_path is None:
        return None

    try:
        result = subprocess.run(
            [str(binary_path), "--version"],
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode == 0:
            # Parse version from output (may be in stdout or stderr)
            output = result.stderr if result.stderr else result.stdout
            if output:
                # Extract just the version line
                for line in output.split('\n'):
                    if line.startswith('version:'):
                        return line.strip()
                # If no version line found, return first non-empty line
                first_line = output.strip().split('\n')[0]
                if first_line:
                    return first_line
        return None
    except Exception:
        return None


def display_binary_version_status(converter: Any) -> None:
    """
    Display binary version information with status message

    Shows version code block and status message comparing installed vs expected version

    Args:
        converter: GGUFConverter instance

    Returns:
        None (displays directly using Streamlit)
    """
    binary_info = get_binary_version(converter)
    expected_version = converter.llama_cpp_manager.LLAMA_CPP_VERSION

    if binary_info["status"] == "ok" and binary_info["version"]:
        st.code(binary_info["version"], language=None)

        # Show version match status
        expected_numeric = expected_version.lstrip('b')
        if expected_numeric not in binary_info["version"]:
            # Extract numeric version from installed version for comparison
            installed_match = re.search(r'b?(\d{4,5})', binary_info["version"])
            if installed_match:
                installed_numeric = int(installed_match.group(1))
                expected_num = int(expected_numeric)
                if installed_numeric > expected_num:
                    st.warning(
                        f"Your version (**b{installed_numeric}**) is newer than "
                        f"YaGGUF's tested version (**{expected_version}**)"
                    )
                else:
                    st.warning(
                        f"Your version (**b{installed_numeric}**) is older than "
                        f"YaGGUF's tested version (**{expected_version}**)"
                    )
            else:
                # Fallback if we can't parse the version
                st.warning(f"Expected binary version: **{expected_version}**")
        else:
            # Show positive confirmation when versions match
            st.info("You are on the latest YaGGUF-tested llama.cpp binary")
    elif binary_info["status"] == "missing":
        st.info(f"Expected binary version: **{expected_version}**")


def get_conversion_scripts_info(converter: Any) -> Dict[str, Any]:
    """
    Get version info for conversion scripts

    Args:
        converter: GGUFConverter instance

    Returns:
        dict: Conversion scripts info with status and message
    """
    from pathlib import Path

    try:
        # Use llama_cpp_manager method to get version info
        version_info = converter.llama_cpp_manager.get_installed_conversion_scripts_version_info()

        if version_info['full_version']:
            return {
                "status": "ok",
                "version": version_info['full_version'],
                "message": "Conversion scripts repository found"
            }

        # Check if directory exists
        project_root = Path(__file__).parent.parent
        llama_cpp_dir = project_root / "llama.cpp"

        if llama_cpp_dir.exists():
            return {
                "status": "ok",
                "version": "unknown",
                "message": "Conversion scripts installed (version check unavailable)"
            }
        else:
            return {
                "status": "missing",
                "version": None,
                "message": "Conversion scripts repository not found. If something went wrong try 'Update Conversion Scripts - Recommended Version.'"
            }

    except Exception as e:
        return {
            "status": "error",
            "version": None,
            "message": f"Error checking conversion scripts: {e}"
        }


def display_conversion_scripts_version_status(converter: Any) -> None:
    """
    Display conversion scripts version information with status message

    Shows version code block and status message comparing installed vs expected version

    Args:
        converter: GGUFConverter instance

    Returns:
        None (displays directly using Streamlit)
    """
    scripts_info = get_conversion_scripts_info(converter)
    expected_version = converter.llama_cpp_manager.LLAMA_CPP_VERSION

    if scripts_info["status"] == "ok" and scripts_info["version"]:
        st.code(f"version: {scripts_info['version']}", language=None)

        # Show version match status
        expected_numeric = expected_version.lstrip('b')
        if expected_numeric in scripts_info["version"]:
            st.info("You are on the latest YaGGUF-tested conversion scripts")
        else:
            # Extract numeric version from installed version for comparison
            installed_match = re.search(r'b?(\d{4,5})', scripts_info["version"])
            if installed_match:
                installed_numeric = int(installed_match.group(1))
                expected_num = int(expected_numeric)
                if installed_numeric > expected_num:
                    st.warning(
                        f"Your version (**b{installed_numeric}**) is newer than "
                        f"YaGGUF's tested version (**{expected_version}**)"
                    )
                else:
                    st.warning(
                        f"Your version (**b{installed_numeric}**) is older than "
                        f"YaGGUF's tested version (**{expected_version}**)"
                    )
            else:
                # Fallback if we can't parse the version
                st.warning(f"Expected conversion scripts version: **{expected_version}**")
    elif scripts_info["status"] == "missing":
        st.info(f"Expected conversion scripts version: **{expected_version}**")


def extract_repo_id_from_url(url_or_repo_id: str) -> Optional[str]:
    """
    Extract repository ID from HuggingFace URL or return the repo ID if already in correct format

    Handles various HuggingFace URL formats:
    - https://huggingface.co/username/model-name
    - https://huggingface.co/username/model-name/tree/main
    - hf.co/username/model-name
    - username/model-name (already in correct format)

    Args:
        url_or_repo_id: HuggingFace URL or repository ID

    Returns:
        str: Extracted repository ID (username/model-name) or None if invalid

    Examples:
        >>> extract_repo_id_from_url("https://huggingface.co/meta-llama/Llama-3.2-3B")
        'meta-llama/Llama-3.2-3B'
        >>> extract_repo_id_from_url("meta-llama/Llama-3.2-3B")
        'meta-llama/Llama-3.2-3B'
    """
    if not url_or_repo_id:
        return None

    url_or_repo_id = url_or_repo_id.strip()

    # Check if it's a URL
    if "huggingface.co/" in url_or_repo_id or "hf.co/" in url_or_repo_id:
        # Match patterns like https://huggingface.co/username/model-name or hf.co/username/model-name
        match = re.search(r'(?:huggingface\.co|hf\.co)/([^/]+/[^/]+)', url_or_repo_id)
        if match:
            return match.group(1)
        return None

    # If not a URL, check if it's already in username/model-name format
    if re.match(r'^[^/]+/[^/]+$', url_or_repo_id):
        return url_or_repo_id

    return None


def run_and_stream_command(command: List[str]) -> None:
    """
    Runs a command and streams its output to a Streamlit container.

    Args:
        command (list): The command and its arguments.
    """
    st.info(f"Running command: `{' '.join(command)}`")
    output_container = st.empty()
    output_container.code("Starting process...", language='bash')

    full_output = ""
    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            errors='replace'
        )

        for line in iter(process.stdout.readline, ''):
            full_output += line
            output_container.code(full_output, language='bash')

        process.stdout.close()
        return_code = process.wait()

        if return_code == 0:
            st.toast("Command completed successfully!")
        else:
            full_output += f"\n--- Command failed with exit code {return_code} ---"
            output_container.code(full_output, language='bash')
            st.toast(f"Command failed with exit code {return_code}")

    except FileNotFoundError:
        full_output = f"Error: Command not found: `{command[0]}`. Make sure it is in your PATH."
        output_container.code(full_output, language='bash')
        st.toast("Command not found.")
    except Exception as e:
        full_output += f"\n--- An error occurred ---\n{str(e)}"
        output_container.code(full_output, language='bash')
        st.toast(f"An error occurred: {e}")


def detect_all_model_files(model_path: Path) -> Dict[str, Dict[str, Any]]:
    """
    Detect all GGUF and safetensors files in a directory (both single and split).

    Args:
        model_path: Path to model directory

    Returns:
        Dictionary mapping file identifier to file info:
        {
            'filename_single': {
                'type': 'single',
                'extension': 'gguf' or 'safetensors',
                'files': [Path object],
                'primary_file': Path,
                'shard_count': 1,
                'total_size_gb': float,
                'display_name': str  # Formatted for dropdown
            },
            'filename_split': {
                'type': 'split',
                'extension': 'gguf' or 'safetensors',
                'files': [Path objects sorted],
                'primary_file': Path,
                'shard_count': int,
                'total_size_gb': float,
                'display_name': str  # Formatted for dropdown
            },
            ...
        }
    """
    from collections import defaultdict

    if not model_path.exists() or not model_path.is_dir():
        return {}

    detected_files = {}

    # Detect GGUF files
    for extension in ['gguf', 'safetensors']:
        # Pattern for split files: {base}-00001-of-00003.{ext}
        split_pattern = re.compile(rf'^(.+)-(\d+)-of-(\d+)\.{extension}$')

        # Track split file groups
        split_groups: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            'files': [],
            'shard_numbers': [],
            'total_expected': 0
        })

        all_files = list(model_path.glob(f"*.{extension}"))

        for file_path in all_files:
            # Try split pattern first
            split_match = split_pattern.match(file_path.name)
            if split_match:
                base_name = split_match.group(1)
                shard_num = int(split_match.group(2))
                total_shards = int(split_match.group(3))

                split_groups[base_name]['files'].append(file_path)
                split_groups[base_name]['shard_numbers'].append(shard_num)
                if split_groups[base_name]['total_expected'] == 0:
                    split_groups[base_name]['total_expected'] = total_shards
            else:
                # Single file
                key = f"{file_path.stem}_{extension}_single"
                file_size_gb = file_path.stat().st_size / (1024**3)

                # For safetensors, show full filename; for GGUF, show stem only
                if extension == 'safetensors':
                    display_name = f"{file_path.name} (single file, {file_size_gb:.2f} GB)"
                else:
                    display_name = f"{file_path.stem} (single file, {file_size_gb:.2f} GB)"

                detected_files[key] = {
                    'type': 'single',
                    'extension': extension,
                    'files': [file_path],
                    'primary_file': file_path,
                    'shard_count': 1,
                    'total_size_gb': file_size_gb,
                    'display_name': display_name
                }

        # Process split file groups
        for base_name, group_info in split_groups.items():
            # Sort files by shard number
            sorted_files = sorted(group_info['files'],
                                key=lambda p: int(split_pattern.match(p.name).group(2)))  # type: ignore[arg-type, union-attr]

            # Check if complete
            expected = set(range(1, group_info['total_expected'] + 1))
            found = set(group_info['shard_numbers'])

            if expected == found:
                # Complete set
                key = f"{base_name}_{extension}_split"
                total_size_gb = sum(f.stat().st_size for f in sorted_files) / (1024**3)

                # For safetensors, show full filename; for GGUF, show base name only
                if extension == 'safetensors':
                    display_name = f"{base_name}.{extension} ({len(sorted_files)} shards, {total_size_gb:.2f} GB)"
                else:
                    display_name = f"{base_name} ({len(sorted_files)} shards, {total_size_gb:.2f} GB)"

                detected_files[key] = {
                    'type': 'split',
                    'extension': extension,
                    'files': sorted_files,
                    'primary_file': sorted_files[0],
                    'shard_count': len(sorted_files),
                    'total_size_gb': total_size_gb,
                    'display_name': display_name
                }

    # Detect PyTorch checkpoint files (.ckpt, .pt, .pth) - always single files
    for ext in ['ckpt', 'pt', 'pth']:
        for file_path in model_path.glob(f"*.{ext}"):
            key = f"{file_path.stem}_{ext}_single"
            file_size_gb = file_path.stat().st_size / (1024**3)
            detected_files[key] = {
                'type': 'single',
                'extension': 'pytorch',
                'files': [file_path],
                'primary_file': file_path,
                'shard_count': 1,
                'total_size_gb': file_size_gb,
                'display_name': f"{file_path.name} ({file_size_gb:.2f} GB)"
            }

    # Detect PyTorch .bin files (single or sharded: name-00001-of-00009.bin)
    bin_split_pattern = re.compile(r'^(.+)-(\d+)-of-(\d+)\.bin$')
    bin_split_groups: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
        'files': [],
        'shard_numbers': [],
        'total_expected': 0
    })
    for file_path in model_path.glob("*.bin"):
        m = bin_split_pattern.match(file_path.name)
        if m:
            base = m.group(1)
            bin_split_groups[base]['files'].append(file_path)
            bin_split_groups[base]['shard_numbers'].append(int(m.group(2)))
            if not bin_split_groups[base]['total_expected']:
                bin_split_groups[base]['total_expected'] = int(m.group(3))
        else:
            key = f"{file_path.stem}_bin_single"
            file_size_gb = file_path.stat().st_size / (1024**3)
            detected_files[key] = {
                'type': 'single',
                'extension': 'pytorch',
                'files': [file_path],
                'primary_file': file_path,
                'shard_count': 1,
                'total_size_gb': file_size_gb,
                'display_name': f"{file_path.name} ({file_size_gb:.2f} GB)"
            }
    for base, info in bin_split_groups.items():
        sorted_files = sorted(info['files'],
                              key=lambda p: int(bin_split_pattern.match(p.name).group(2)))  # type: ignore[union-attr]
        if set(range(1, info['total_expected'] + 1)) == set(info['shard_numbers']):
            key = f"{base}_bin_split"
            total_size_gb = sum(f.stat().st_size for f in sorted_files) / (1024**3)
            detected_files[key] = {
                'type': 'split',
                'extension': 'pytorch',
                'files': sorted_files,
                'primary_file': sorted_files[0],
                'shard_count': len(sorted_files),
                'total_size_gb': total_size_gb,
                'display_name': f"{base}.bin ({len(sorted_files)} shards, {total_size_gb:.2f} GB)"
            }

    return detected_files


def show_processing_overlay(message: str = "Processing...") -> Any:
    """
    Display a full-screen overlay that blocks all user interaction.

    This is useful for long-running operations where clicking other widgets
    would cause issues. The overlay covers the entire viewport and intercepts
    all click events.

    Args:
        message: Text to display on the overlay (default: "Processing...")

    Returns:
        A Streamlit empty container that can be cleared via .empty() to remove
        the overlay after processing completes.

    Example:
        overlay = show_processing_overlay("Converting...")
        try:
            do_long_running_task()
        finally:
            overlay.empty()  # Remove overlay when done

    Note:
        The overlay uses CSS position:fixed to cover the viewport and a high
        z-index to sit above Streamlit widgets. The pointer-events:all ensures
        clicks are captured by the overlay rather than passing through.
    """
    overlay_html = f"""
    <style>
        .yagguf-processing-overlay {{
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            background-color: rgba(14, 17, 23, 0.85) !important;
            z-index: 1000001 !important;
            display: flex !important;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            pointer-events: all !important;
            cursor: wait;
        }}
        .yagguf-processing-message {{
            color: #fafafa;
            font-size: 1.5rem;
            font-weight: 500;
            margin-bottom: 1rem;
            animation: yagguf-pulse 2s ease-in-out infinite;
        }}
        .yagguf-processing-spinner {{
            width: 50px;
            height: 50px;
            border: 4px solid rgba(255, 255, 255, 0.2);
            border-top-color: #ff4b4b;
            border-radius: 50%;
            animation: yagguf-spin 1s linear infinite;
        }}
        .yagguf-processing-hint {{
            color: rgba(250, 250, 250, 0.6);
            font-size: 0.9rem;
            margin-top: 1.5rem;
        }}
        @keyframes yagguf-pulse {{
            0%, 100% {{ opacity: 1; }}
            50% {{ opacity: 0.6; }}
        }}
        @keyframes yagguf-spin {{
            to {{ transform: rotate(360deg); }}
        }}
    </style>
    <div class="yagguf-processing-overlay">
        <div class="yagguf-processing-spinner"></div>
        <div class="yagguf-processing-message">{message}</div>
        <div class="yagguf-processing-hint">Please wait - do not close this tab</div>
    </div>
    """
    placeholder = st.empty()
    placeholder.markdown(overlay_html, unsafe_allow_html=True)
    return placeholder
