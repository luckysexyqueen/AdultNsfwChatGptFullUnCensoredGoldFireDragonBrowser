import pytest


@pytest.fixture(scope="module")
def flash_llama_marlin24_handle(launcher):
    with launcher(
        "nm-testing/Llama-2-7b-pruned2.4-Marlin_24", quantize="marlin"
    ) as handle:
        yield handle


@pytest.fixture(scope="module")
async def flash_llama_marlin(flash_llama_marlin24_handle):
    await flash_llama_marlin24_handle.health(300)
    return flash_llama_marlin24_handle.client


@pytest.mark.skip(reason="Issue with the model access")
@pytest.mark.release
@pytest.mark.asyncio
@pytest.mark.private
async def test_flash_llama_marlin(flash_llama_marlin, response_snapshot):
    response = await flash_llama_marlin.generate(
        "Test request", max_new_tokens=10, decoder_input_details=True
    )

    assert response.details.generated_tokens == 10
    assert response == response_snapshot


@pytest.mark.skip(reason="Issue with the model access")
@pytest.mark.release
@pytest.mark.asyncio
@pytest.mark.private
async def test_flash_llama_marlin24_all_params(flash_llama_marlin, response_snapshot):
    response = await flash_llama_marlin.generate(
        "Test request",
        max_new_tokens=10,
        repetition_penalty=1.2,
        return_full_text=True,
        temperature=0.5,
        top_p=0.9,
        top_k=10,
        truncate=5,
        typical_p=0.9,
        watermark=True,
        decoder_input_details=True,
        seed=0,
    )

    assert response.details.generated_tokens == 10
    assert response == response_snapshot


@pytest.mark.skip(reason="Issue with the model access")
@pytest.mark.release
@pytest.mark.asyncio
@pytest.mark.private
async def test_flash_llama_marlin24_load(
    flash_llama_marlin, generate_load, response_snapshot
):
    responses = await generate_load(
        flash_llama_marlin, "Test request", max_new_tokens=10, n=4
    )

    assert len(responses) == 4
    assert all([r.generated_text == responses[0].generated_text for r in responses])

    assert responses == response_snapshot
