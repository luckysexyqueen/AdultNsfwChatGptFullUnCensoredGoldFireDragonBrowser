# Pipeline options

The `pipeline(task, model?, options?)` factory accepts a common set of options
across every task. Task-specific call options are documented on each pipeline
class in the [API reference](https://huggingface.co/docs/transformers.js/api/pipelines).

## Common options

<!-- @generated:start id=typedef:PretrainedModelOptions -->
| Option | Type | Description |
|--------|------|-------------|
| `progress_callback`? | `ProgressCallback` | If specified, this function is called during model construction with progress updates. _(default: `null`)_ |
| `config`? | `PretrainedConfig` | Configuration to use for the model instead of an automatically loaded configuration. Configuration can be automatically loaded when:<br />- The model is provided by the library and loaded with the *model ID* string of a pretrained model.<br />- The model is loaded by supplying a local directory as `pretrained_model_name_or_path` and a configuration JSON file named *config.json* is found in the directory. _(default: `null`)_ |
| `cache_dir`? | `string` | Path to a directory where downloaded model files should be cached if the standard cache should not be used. _(default: `null`)_ |
| `local_files_only`? | `boolean` | Whether to only look at local files (e.g., not try downloading the model). _(default: `false`)_ |
| `revision`? | `string` | The model revision to use. This can be a branch name, tag name, or commit ID. Because the Hub uses Git-based storage, `revision` can be any identifier accepted by Git. Ignored for local requests. _(default: `'main'`)_ |
| `subfolder`? | `string` | In case the relevant files are located inside a subfolder of the model repo on huggingface.co, you can specify the folder name here. _(default: `'onnx'`)_ |
| `model_file_name`? | `string` | Override the base ONNX model file name, excluding dtype and `.onnx` suffixes. This is most useful for single-session models. _(default: `null`)_ |
| `device`? | `DeviceType\|Record<string, DeviceType>` | The device to run the model on. If not specified, the device will be chosen from the environment settings. _(default: `null`)_ |
| `dtype`? | `DataType\|Record<string, DataType>` | The data type to use for the model. If not specified, the data type will be chosen from the environment settings. _(default: `null`)_ |
| `use_external_data_format`? | `ExternalData\|Record<string, ExternalData>` | Whether to load external data files. `null` uses the model configuration; `false` disables external data; `true` uses one chunk; a number selects the chunk count. _(default: `null`)_ |
| `session_options`? | `InferenceSession.SessionOptions` | User-specified ONNX Runtime session options. Suitable defaults are filled in when omitted. _(default: `{}`)_ |
<!-- @generated:end id=typedef:PretrainedModelOptions -->

## Progress tracking

The `progress_total` event reports aggregate progress across every file the model needs,
which is what a loading bar usually wants:

```javascript
const pipe = await pipeline("sentiment-analysis", null, {
  progress_callback: (info) => {
    if (info.status === "progress_total") {
      console.log(`Loading model: ${info.progress.toFixed(1)}%`);
    }
  },
});
```

For per-file detail, listen for `progress` events instead:

```javascript
const pipe = await pipeline("sentiment-analysis", null, {
  progress_callback: (info) => {
    if (info.status === "progress") {
      console.log(`${info.file}: ${info.progress.toFixed(1)}%`);
    }
  },
});
```

### `ProgressInfo` shape

<!-- @generated:start id=typedef:ProgressInfo -->
**`InitiateProgressInfo`**

| Option | Type | Description |
|--------|------|-------------|
| `status` | `'initiate'` | A file load is about to start. |
| `name` | `string` | The model ID or directory path. |
| `file` | `string` | The name of the file. |

**`DownloadProgressInfo`**

| Option | Type | Description |
|--------|------|-------------|
| `status` | `'download'` | A file download has started. |
| `name` | `string` | The model ID or directory path. |
| `file` | `string` | The name of the file. |

**`ProgressStatusInfo`**

| Option | Type | Description |
|--------|------|-------------|
| `status` | `'progress'` | A file download has reported byte progress. |
| `name` | `string` | The model ID or directory path. |
| `file` | `string` | The name of the file. |
| `progress` | `number` | A number between 0 and 100. |
| `loaded` | `number` | The number of bytes loaded. |
| `total` | `number` | The total number of bytes to be loaded. |

**`DoneProgressInfo`**

| Option | Type | Description |
|--------|------|-------------|
| `status` | `'done'` | A file has finished loading. |
| `name` | `string` | The model ID or directory path. |
| `file` | `string` | The name of the file. |

**`ReadyProgressInfo`**

| Option | Type | Description |
|--------|------|-------------|
| `status` | `'ready'` | The requested pipeline is ready to use. |
| `task` | `string` | The loaded task. |
| `model` | `string` | The loaded model. |

**`TotalProgressInfo`**

| Option | Type | Description |
|--------|------|-------------|
| `status` | `'progress_total'` | Aggregate progress across all files being loaded. |
| `name` | `string` | The model ID or directory path. |
| `progress` | `number` | A number between 0 and 100. |
| `loaded` | `number` | The number of bytes loaded. |
| `total` | `number` | The total number of bytes to be loaded. |
| `files` | `FilesLoadingMap` | A mapping of file names to their loading progress. |
<!-- @generated:end id=typedef:ProgressInfo -->

## Device selection

```javascript
// Default — CPU (onnxruntime-node in Node.js, WASM in browsers)
await pipeline("sentiment-analysis", null);

// GPU via WebGPU (Chrome 113+, fastest for big models)
await pipeline("text-generation", "onnx-community/Qwen3-0.6B-ONNX", {
  device: "webgpu",
  dtype: "fp16",
});

// Node.js with onnxruntime-node
await pipeline("sentiment-analysis", null, { device: "cpu" });
```

Detect WebGPU support before attempting to use it:

```javascript
const hasWebGPU = typeof navigator !== "undefined" && "gpu" in navigator;
const pipe = await pipeline("text-generation", "onnx-community/Qwen3-0.6B-ONNX", {
  device: hasWebGPU ? "webgpu" : "wasm",
  dtype: hasWebGPU ? "fp16" : "q8",
});
```

## Task-specific call options

Once created, each pipeline is itself callable with task-specific options:

```javascript
const classifier = await pipeline("text-classification");
await classifier("great movie", { top_k: 3 });

const generator = await pipeline("text-generation");
await generator("Once upon a time", { max_new_tokens: 100, do_sample: true, temperature: 0.7 });

const translator = await pipeline("translation", "Xenova/nllb-200-distilled-600M");
await translator("Hello", { src_lang: "eng_Latn", tgt_lang: "fra_Latn" });
```

The per-task recipes in [`TASKS.md`](./TASKS.md) show the most common call
options in use. For the exhaustive option types of a specific pipeline, see the
[API reference](https://huggingface.co/docs/transformers.js/api/pipelines).

## Generation parameters

Every field below can be passed as an option to a `text-generation`,
`text2text-generation`, `translation`, or `summarization` pipeline call, or
anywhere `generate()` is invoked directly.

**Pairs of fields with overlapping meanings:**

- `max_new_tokens` overrides `max_length`. Pass one, not both — `max_new_tokens`
  is usually what you want because it doesn't depend on the prompt length.
- `min_new_tokens` overrides `min_length` for the same reason.
- Sampling vs. greedy: `temperature` and `top_k` only take effect with
  `do_sample: true`. Under greedy decoding (the default) they are silently
  ignored.
- Beam search is not yet implemented: `num_beams > 1` is accepted but
  generation still keeps a single sequence, so leave it at the default.

<!-- @generated:start id=fields:GenerationConfig -->
| Option | Type | Description |
|--------|------|-------------|
| `max_length`? | `number` | The maximum length the generated tokens can have. Corresponds to the length of the input prompt + `max_new_tokens`. Its effect is overridden by `max_new_tokens`, if also set. _(default: `20`)_ |
| `max_new_tokens`? | `number` | The maximum number of tokens to generate, ignoring the number of tokens in the prompt. _(default: `null`)_ |
| `min_length`? | `number` | The minimum length of the sequence to be generated. Corresponds to the length of the input prompt + `min_new_tokens`. Its effect is overridden by `min_new_tokens`, if also set. _(default: `0`)_ |
| `min_new_tokens`? | `number` | The minimum number of tokens to generate, ignoring the number of tokens in the prompt. _(default: `null`)_ |
| `early_stopping`? | `boolean\|"never"` | Controls the stopping condition for beam-based methods, like beam-search. It accepts the following values:<br />- `true`, where the generation stops as soon as there are `num_beams` complete candidates;<br />- `false`, where a heuristic is applied and the generation stops when it is very unlikely to find better candidates;<br />- `"never"`, where the beam search procedure only stops when there cannot be better candidates (canonical beam search algorithm). _(default: `false`)_ |
| `max_time`? | `number` | The maximum time, in seconds, allowed for generation. Generation will still finish the current pass after the allocated time has passed. _(default: `null`)_ |
| `do_sample`? | `boolean` | Whether to use sampling; use greedy decoding otherwise. _(default: `false`)_ |
| `num_beams`? | `number` | Number of beams for beam search. 1 means no beam search. _(default: `1`)_ |
| `num_beam_groups`? | `number` | Number of groups to divide `num_beams` into to encourage diversity among different groups of beams. See [this paper](https://huggingface.co/papers/1610.02424) for more details. _(default: `1`)_ |
| `penalty_alpha`? | `number` | Balance model confidence against the degeneration penalty during contrastive search decoding. _(default: `null`)_ |
| `use_cache`? | `boolean` | Whether the model should reuse past key/value states, when supported, to speed up decoding. _(default: `true`)_ |
| `temperature`? | `number` | The value used to modulate the next token probabilities. _(default: `1.0`)_ |
| `top_k`? | `number` | The number of highest-probability vocabulary tokens to keep for top-k filtering. _(default: `50`)_ |
| `top_p`? | `number` | If set to a float below 1, only the smallest set of most probable tokens with probabilities that add up to `top_p` or higher are kept for generation. _(default: `1.0`)_ |
| `typical_p`? | `number` | Local typicality measures how similar the conditional probability of predicting a target token next is to the expected conditional probability of predicting a random token next, given the partial text already generated. If set to a float below 1, the smallest set of the most locally typical tokens with probabilities that add up to `typical_p` or higher are kept for generation. See [this paper](https://huggingface.co/papers/2202.00666) for more details. _(default: `1.0`)_ |
| `epsilon_cutoff`? | `number` | If set to a float strictly between 0 and 1, only tokens with a conditional probability greater than `epsilon_cutoff` will be sampled. In the paper, suggested values range from 3e-4 to 9e-4, depending on the size of the model. See [Truncation Sampling as Language Model Desmoothing](https://huggingface.co/papers/2210.15191) for more details. _(default: `0.0`)_ |
| `eta_cutoff`? | `number` | Eta sampling is a hybrid of locally typical sampling and epsilon sampling. If set to a float strictly between 0 and 1, a token is only considered if it is greater than either `eta_cutoff` or `sqrt(eta_cutoff) * exp(-entropy(softmax(next_token_logits)))`. The latter term is intuitively the expected next token probability, scaled by `sqrt(eta_cutoff)`. In the paper, suggested values range from 3e-4 to 2e-3, depending on the size of the model. See [Truncation Sampling as Language Model Desmoothing](https://huggingface.co/papers/2210.15191) for more details. _(default: `0.0`)_ |
| `diversity_penalty`? | `number` | This value is subtracted from a beam's score if it generates the same token as any beam from another group at a particular time. Note that `diversity_penalty` is only effective if `group beam search` is enabled. _(default: `0.0`)_ |
| `repetition_penalty`? | `number` | Penalty applied to repeated tokens. 1.0 means no penalty. See [this paper](https://huggingface.co/papers/1909.05858) for more details. _(default: `1.0`)_ |
| `encoder_repetition_penalty`? | `number` | Penalty applied to sequences that are not in the original input. 1.0 means no penalty. _(default: `1.0`)_ |
| `length_penalty`? | `number` | Exponential penalty applied to sequence length during beam-based generation. It is applied as an exponent to the sequence length, which in turn is used to divide the score of the sequence. Since the score is the log likelihood of the sequence (i.e. negative), `length_penalty` > 0.0 promotes longer sequences, while `length_penalty` < 0.0 encourages shorter sequences. _(default: `1.0`)_ |
| `no_repeat_ngram_size`? | `number` | If set to an integer greater than 0, all n-grams of that size can only occur once. _(default: `0`)_ |
| `bad_words_ids`? | `number[][]` | List of token IDs that are not allowed to be generated. In order to get the token IDs of the words that should not appear in the generated text, use `tokenizer(bad_words, { add_prefix_space: true, add_special_tokens: false }).input_ids`. _(default: `null`)_ |
| `force_words_ids`? | `number[][]\|number[][][]` | List of token IDs that must be generated. If given a `number[][]`, this is treated as a simple list of words that must be included, the opposite of `bad_words_ids`. If given `number[][][]`, this triggers a [disjunctive constraint](https://github.com/huggingface/transformers/issues/14081), which allows different forms of each word. _(default: `null`)_ |
| `renormalize_logits`? | `boolean` | Whether to renormalize the logits after applying all the logits processors or warpers (including the custom ones). It's highly recommended to set this flag to `true` because search algorithms assume the score logits are normalized, but some logit processors or warpers break the normalization. _(default: `false`)_ |
| `constraints`? | `Object[]` | Custom constraints that guide generation to include certain tokens as defined by `Constraint` objects. _(default: `null`)_ |
| `forced_bos_token_id`? | `number` | The ID of the token to force as the first generated token after the `decoder_start_token_id`. Useful for multilingual models like mBART where the first generated token needs to be the target language token. _(default: `null`)_ |
| `forced_eos_token_id`? | `number\|number[]` | The ID of the token to force as the last generated token when `max_length` is reached. Optionally, use a list to set multiple *end-of-sequence* tokens. _(default: `null`)_ |
| `remove_invalid_values`? | `boolean` | Whether to remove possible *nan* and *inf* outputs of the model to prevent the generation method from crashing. Note that using `remove_invalid_values` can slow down generation. _(default: `false`)_ |
| `exponential_decay_length_penalty`? | `[number, number]` | This tuple adds an exponentially increasing length penalty after a certain number of tokens have been generated. The tuple consists of: `(start_index, decay_factor)` where `start_index` indicates where the penalty starts and `decay_factor` represents the factor of exponential decay. _(default: `null`)_ |
| `suppress_tokens`? | `number[]` | A list of tokens to suppress during generation. The `SuppressTokens` logit processor sets their log probabilities to `-inf` so that they are not sampled. _(default: `null`)_ |
| `streamer`? | `TextStreamer` | Streamer used to yield generated text incrementally. _(default: `null`)_ |
| `begin_suppress_tokens`? | `number[]` | A list of tokens to suppress at the beginning of the generation. The `SuppressBeginTokens` logit processor sets their log probabilities to `-inf` so that they are not sampled. _(default: `null`)_ |
| `forced_decoder_ids`? | `[number, number][]` | A list of integer pairs that maps generation indices to token indices that will be forced before sampling. For example, `[[1, 123]]` means the second generated token will always be a token of index 123. _(default: `null`)_ |
| `guidance_scale`? | `number` | The guidance scale for classifier-free guidance (CFG). CFG is enabled by setting `guidance_scale > 1`. Higher guidance scale encourages the model to generate samples that are more closely tied to the input prompt, usually at the expense of poorer quality. _(default: `null`)_ |
| `num_return_sequences`? | `number` | The number of independently computed returned sequences for each element in the batch. _(default: `1`)_ |
| `output_attentions`? | `boolean` | Whether to return attention tensors from all attention layers. See `attentions` under returned tensors for more details. _(default: `false`)_ |
| `output_hidden_states`? | `boolean` | Whether to return the hidden states of all layers. See `hidden_states` under returned tensors for more details. _(default: `false`)_ |
| `output_scores`? | `boolean` | Whether to return the prediction scores. See `scores` under returned tensors for more details. _(default: `false`)_ |
| `return_dict_in_generate`? | `boolean` | Whether to return a `ModelOutput` instead of a plain tuple. _(default: `false`)_ |
| `pad_token_id`? | `number` | The ID of the *padding* token. _(default: `null`)_ |
| `bos_token_id`? | `number` | The ID of the *beginning-of-sequence* token. _(default: `null`)_ |
| `eos_token_id`? | `number\|number[]` | The ID of the *end-of-sequence* token. Optionally, use a list to set multiple *end-of-sequence* tokens. _(default: `null`)_ |
| `encoder_no_repeat_ngram_size`? | `number` | If set to an integer greater than 0, all n-grams of that size that occur in the `encoder_input_ids` cannot occur in the `decoder_input_ids`. _(default: `0`)_ |
| `decoder_start_token_id`? | `number` | If an encoder-decoder model starts decoding with a token other than *bos*, the ID of that token. _(default: `null`)_ |
| `generation_kwargs`? | `Object` | Additional generation kwargs forwarded to the model's `generate` function. Kwargs that are not present in `generate`'s signature are used in the model forward pass. _(default: `{}`)_ |
<!-- @generated:end id=fields:GenerationConfig -->

### Streaming tokens as they're produced

```javascript
import { pipeline, TextStreamer } from "@huggingface/transformers";

const generator = await pipeline("text-generation", "onnx-community/Qwen3-0.6B-ONNX");
const streamer = new TextStreamer(generator.tokenizer, {
  skip_prompt: true,
  skip_special_tokens: true,
  callback_function: (text) => process.stdout.write(text),
});

await generator("Tell me a short story.", { max_new_tokens: 200, streamer });
```

For whisper-style chunk / token / finalize callbacks, use `WhisperTextStreamer`.

### KV cache reuse across calls

For multi-turn chat, pass the same `DynamicCache` to every call **and re-send the full
conversation each turn**. The pipeline uses the cache to skip re-encoding the tokens it
has already processed (the shared prefix). Do not pass only the new message: the model
needs the full sequence to compute token positions, so incremental-only input produces
wrong results.

```javascript
import { pipeline, DynamicCache } from "@huggingface/transformers";

const generator = await pipeline("text-generation", "onnx-community/Qwen3-0.6B-ONNX");
const past_key_values = new DynamicCache();
const messages = [{ role: "user", content: "What is the capital of France?" }];

// Turn 1
const turn1 = await generator(messages, { max_new_tokens: 128, past_key_values });
messages.push(turn1[0].generated_text.at(-1)); // append the assistant reply

// Turn 2: send the full conversation again — only the new tokens are encoded
messages.push({ role: "user", content: "What about Germany?" });
const turn2 = await generator(messages, { max_new_tokens: 128, past_key_values });
console.log(turn2[0].generated_text.at(-1).content);

await past_key_values.dispose(); // free the cache tensors when the conversation ends
```
