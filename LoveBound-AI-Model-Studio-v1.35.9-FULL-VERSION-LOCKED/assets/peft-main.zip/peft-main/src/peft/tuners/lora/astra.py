# Copyright 2026-present the HuggingFace Inc. team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Reference code: https://github.com/LyoAI/Astra/blob/main/astra.py
# Reference paper: https://huggingface.co/papers/2602.19111
# This implementation builds on `corda.py`.

import os
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from typing import Any, Optional

import torch
from torch import nn
from tqdm import tqdm
from transformers.pytorch_utils import Conv1D

from peft.tuners.lora.config import LoraConfig
from peft.tuners.lora.model import LoraModel
from peft.utils.other import get_pattern_key


@dataclass
class AstraEigens:
    S: torch.Tensor
    V: torch.Tensor


def target_modules(model: nn.Module, config: LoraConfig) -> Iterable[nn.Module]:
    """
    Iterate over Astra target name and modules of a model. A module is a target if its name is in
    `config.target_modules` and is `nn.Linear` or `Conv1D`.
    """
    if config.target_modules is None:
        raise ValueError(
            "`target_modules` must be set explicitly for Astra preprocessing because covariance matrices are "
            "collected from the targeted modules."
        )
    for name, module in model.named_modules():
        if LoraModel._check_target_module_exists(config, name) and isinstance(module, (nn.Linear, Conv1D)):
            yield name, module


def get_model_device(model: nn.Module) -> str:
    if hasattr(model, "module"):  # Handle DeepSpeed/DataParallel
        model = model.module
    return next(iter(model.parameters())).device.type


@torch.no_grad()
def preprocess_astra(
    model: nn.Module,
    lora_config: LoraConfig,
    run_model: Optional[Callable[[], None]] = None,
    hooked_model: Optional[nn.Module] = None,
):
    """
    Build necessary Astra fields for a model.

    For each `M * N` linear layer, a `M * M` covariance matrix will be built temporarily during the preprocessing
    process, consuming roughly another `2 * MODEL_SIZE` memory for typical LLMs if model weight is FP16 and covariance
    is FP32. If that's too much, consider specifying `use_float16_for_covariance` in `lora_config.astra_config`.

    Args:
        model (`nn.Module`):
            Model to preprocess.
        lora_config (`LoraConfig`):
            Lora configuration of the model. `lora_config.astra_config` should be set. `lora_config.target_modules`
            must be set explicitly.
        run_model (`Optional[Callable[[], None]]`):
            Callback to run the model when building covariance. Typically you should run model inference on your sample
            dataset in this callback. Experiments have shown that when token count per sample is 2048, hidden dimension
            is 4096, collecting 256 distinct samples is enough. If you collect too few or too repetitive samples, the
            covariance matrix may be low-ranked and unstabilize preprocessing. You can estimate sample count as
            `HIDDEN_DIM / TOKEN_PER_SAMPLE * 128`. `run_model` can be `None` only if covariance file in
            `lora_config.astra_config` is already created.
        hooked_model (`Optional[nn.Module]`):
            Model to hook when building covariance. If none, original model will be hooked. This is only useful when
            you want to hook a different model than the one you are training, typically you should leave this `None`.

    Upon completion, the following fields are set for each target module:
        eigens.S (`torch.Tensor`):
            Eigenvalue of the collected output activations' covariance matrix.
        eigens.V (`torch.Tensor`):
            Eigenvectors of the collected output activations' covariance matrix.
    """
    if lora_config.astra_config is None:
        raise ValueError(
            "`lora_config.astra_config` must be set to use Astra. Set `init_lora_weights='astra'` and pass an "
            "`AstraConfig`."
        )

    cache_file = lora_config.astra_config.cache_file
    covariance_file = lora_config.astra_config.covariance_file
    verbose = lora_config.astra_config.verbose
    prune_temporary_fields = lora_config.astra_config.prune_temporary_fields

    if cache_file is not None and os.path.exists(cache_file) and os.path.getsize(cache_file) > 0:
        cache = torch.load(cache_file, map_location=get_model_device(model), weights_only=True)
        for name, module in target_modules(model, lora_config):
            module.eigens = AstraEigens(
                S=cache[f"{name}.eigens.S"],
                V=cache[f"{name}.eigens.V"],
            )
    else:
        for name, module in target_modules(model, lora_config):
            r_key = get_pattern_key(lora_config.rank_pattern.keys(), name)
            module.rank = lora_config.rank_pattern.get(r_key, lora_config.r)

        calib_cov_distribution(model, lora_config, run_model, hooked_model, covariance_file)

        collect_eigens(model, lora_config, verbose)

        crop_astra_eigens(model, lora_config)

        if prune_temporary_fields:
            for name, module in target_modules(model, lora_config):
                if hasattr(module, "sample_count"):
                    del module.sample_count
                if hasattr(module, "covariance_matrix"):
                    del module.covariance_matrix
                if hasattr(module, "rank"):
                    del module.rank

        if cache_file is not None:
            cache: dict[str, Any] = {}
            for name, module in target_modules(model, lora_config):
                cache[f"{name}.eigens.S"] = module.eigens.S
                cache[f"{name}.eigens.V"] = module.eigens.V

            if dirname := os.path.dirname(cache_file):
                os.makedirs(dirname, exist_ok=True)
            torch.save(cache, cache_file)


@torch.no_grad()
def calib_cov_distribution(
    model: nn.Module,
    config: LoraConfig,
    run_model: Optional[Callable[[], None]],
    hooked_model: Optional[nn.Module],
    covariance_file: Optional[str],
):
    if covariance_file is not None and os.path.exists(covariance_file) and os.path.getsize(covariance_file) > 0:
        all_covariance_matrix = torch.load(covariance_file, map_location=get_model_device(model), weights_only=True)
        for name, module in target_modules(model, config):
            module.covariance_matrix = all_covariance_matrix[name]
        return

    if run_model is None:
        raise ValueError("run_model must be specified when covariance file and cache file aren't built.")
    if hooked_model is None:
        hooked_model = model
    hooked_model.eval()

    def hook(module, input, output):
        # Astra builds the covariance matrix of the module output activations, e.g. of shape
        # (batch_size, context_length, dim), so the first element is the actual output tensor in case a tuple is
        # returned. All leading dimensions are flattened to obtain a (num_tokens, dim) matrix.
        output = output[0] if isinstance(output, (tuple, list)) else output
        output = output.detach().reshape(-1, output.size(-1)).data  # (num_tokens, dim)
        if not config.astra_config.use_float16_for_covariance:
            output = output.float()
        # scale the activations to make the covariance invariant to their magnitude
        output = output / torch.max(output).abs()

        # check if output is valid
        if torch.isnan(output).any() or torch.isinf(output).any():
            raise ValueError("Invalid value found in output, please check your output data.")

        # calculate covariance and check if it's valid
        covariance = output.t().matmul(output)
        if torch.isnan(covariance).any() or torch.isinf(covariance).any():
            raise ValueError(
                "Invalid value found in covariance. Please file an issue at https://github.com/huggingface/peft/issues."
            )

        # add to module
        module.sample_count += 1
        module.covariance_matrix += covariance

        # free memory
        del covariance, output

    handles = []
    for name, module in target_modules(hooked_model, config):
        module.sample_count = 0
        module.covariance_matrix = 0
        handles.append(module.register_forward_hook(hook))

    run_model()

    # Clear the hooks
    for handle in handles:
        handle.remove()

    # In some edge cases you might need to hook a model different from the model to add adapters,
    # this case you would specify `hooked_model` and set it to a different model from `model`.
    if hooked_model is not model:
        targets = {}
        for name, module in target_modules(model, config):
            targets[name] = module
        for name, module in target_modules(hooked_model, config):
            # There can be modules used only in inference, but not training
            # Exclude modules not in target model to prevent KeyError in this case
            if name in targets:
                targets[name].sample_count = module.sample_count
                targets[name].covariance_matrix = module.covariance_matrix

    # Divide by sample count
    for name, module in target_modules(model, config):
        module.covariance_matrix /= module.sample_count

    # Save covariance to disk
    if covariance_file is not None:
        all_covariance_matrix = {}
        for name, module in target_modules(model, config):
            all_covariance_matrix[name] = module.covariance_matrix
        if dirname := os.path.dirname(covariance_file):
            os.makedirs(dirname, exist_ok=True)
        torch.save(all_covariance_matrix, covariance_file)


@torch.no_grad()
def collect_eigens(model: nn.Module, config: LoraConfig, verbose: bool):
    """Call collect_eigens_for_layer and store result in key `eigens` of each layer."""
    linear_modules = []
    for name, module in target_modules(model, config):
        linear_modules.append((name, module))
    if verbose:
        linear_modules = tqdm(linear_modules, desc="Collecting eigens")
    for name, module in linear_modules:
        module.eigens = collect_eigens_for_layer(module)


@torch.no_grad()
def collect_eigens_for_layer(linear: nn.Linear) -> AstraEigens:
    if not hasattr(linear, "covariance_matrix"):
        raise ValueError(
            "Covariance matrix not found in linear module. Please do not call this function directly, "
            "instead call `preprocess_astra`. If your usage is correct but this error still encounters, "
            "please file an issue at https://github.com/huggingface/peft/issues."
        )
    covariance_matrix = linear.covariance_matrix.float()
    dim = covariance_matrix.size(0)
    S, V = torch.linalg.eigh(covariance_matrix)

    # Sanity check, temporarily S and V are large, they will be cropped after rank search
    if S.size(0) != dim:
        raise ValueError(
            f"Matrix S size mismatch: {S.size()} vs. ({dim},), "
            "please file an issue at https://github.com/huggingface/peft/issues."
        )
    if V.size(0) != dim or V.size(1) != dim:
        raise ValueError(
            f"Matrix V size mismatch: {V.size()} vs. ({dim}, {dim}), "
            "please file an issue at https://github.com/huggingface/peft/issues."
        )

    # Offload S and V to CPU, they consume too much memory
    S = S.cpu()
    V = V.cpu()
    return AstraEigens(
        S=S,
        V=V,
    )


@torch.no_grad()
def crop_astra_eigens(model: nn.Module, config: LoraConfig):
    for name, module in target_modules(model, config):
        # For Conv1D, weight is stored as (in_features, out_features), transposed compared to Linear
        # But eigens are computed on the module output, so we need to account for this
        weight_out_dim = module.weight.size(1) if isinstance(module, Conv1D) else module.weight.size(0)

        if module.rank > weight_out_dim:
            raise ValueError(
                f"Astra requires `r` <= out_features but got r={module.rank} for a layer with weight shape "
                f"{tuple(module.weight.shape)} (max usable r is {weight_out_dim})."
            )

        # We don't expect saving sliced tensor writes the whole tensor to disk,
        # so it's necessary to copy the tensors.
        # Reference: https://github.com/pytorch/pytorch/issues/40157
        module.eigens.S = module.eigens.S.clone()
        module.eigens.V = module.eigens.V[:, -module.rank :].clone().to(get_model_device(model))

        # Sanity check
        if module.eigens.S.size(0) != weight_out_dim:
            raise ValueError(
                f"Matrix S size mismatch: {module.eigens.S.size(0)} vs. ({weight_out_dim},),"
                "please file an issue at https://github.com/huggingface/peft/issues."
            )
        if module.eigens.V.size(0) != weight_out_dim:
            raise ValueError(
                f"Matrix V size mismatch: {module.eigens.V.size(0)} vs. ({weight_out_dim},),"
                "please file an issue at https://github.com/huggingface/peft/issues."
            )
        if module.eigens.V.size(1) != module.rank:
            raise ValueError(
                f"Matrix V size mismatch: {module.eigens.V.size(1)} vs. ({module.rank},),"
                "please file an issue at https://github.com/huggingface/peft/issues."
            )
