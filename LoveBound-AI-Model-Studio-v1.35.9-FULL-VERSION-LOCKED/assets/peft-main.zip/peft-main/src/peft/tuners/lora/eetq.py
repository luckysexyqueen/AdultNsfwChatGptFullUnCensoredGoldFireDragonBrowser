# Copyright 2024-present the HuggingFace Inc. team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import Any, Optional

import torch

from peft.import_utils import is_eetq_available
from peft.tuners.lora.layer import LoraLayer
from peft.tuners.tuners_utils import BaseTunerLayer

from .config import LoraConfig


if is_eetq_available():
    from eetq import EetqLinear

    try:
        from transformers.integrations.eetq import EetqLinear as TransformersEetqLinear

        # in newer transformers versions, EETQ quantization uses a transformers-specific class
        eetq_classes = (EetqLinear, TransformersEetqLinear)
    except ImportError:
        eetq_classes = (EetqLinear,)

    class EetqLoraLinear(torch.nn.Module, LoraLayer):
        def __init__(
            self,
            base_layer,
            adapter_name,
            config: LoraConfig,
            r: int = 0,
            lora_alpha: int = 1,
            **kwargs,
        ):
            if config.use_dora:
                raise ValueError(f"{self.__class__.__name__} does not support DoRA yet, please set it to False")
            if config.velora_config is not None:
                raise ValueError(f"{self.__class__.__name__} does not support VeLoRA yet, please set it to False")

            super().__init__()
            LoraLayer.__init__(self, base_layer)

            # self.base_layer and self.quant_linear_module are the same; we need the former for consistency and the latter
            # for backwards compatibility
            self.quant_linear_module = base_layer

            self._active_adapter = adapter_name
            self.update_layer(
                adapter_name,
                r,
                lora_alpha=lora_alpha,
                config=config,
            )

        def forward(self, x: torch.Tensor):
            result = self.quant_linear_module(x)

            if self.disable_adapters:
                return result

            for active_adapter in self.active_adapters:
                if active_adapter not in self.lora_A.keys():
                    continue
                lora_A = self.lora_A[active_adapter]
                lora_B = self.lora_B[active_adapter]
                dropout = self.lora_dropout[active_adapter]
                scaling = self.scaling[active_adapter]

                requires_conversion = not torch.is_autocast_enabled()
                if requires_conversion:
                    expected_dtype = result.dtype
                    x = self._cast_input_dtype(x, lora_A.weight.dtype)

                output = lora_B(lora_A(dropout(x)))
                if requires_conversion:
                    output = output.to(expected_dtype)
                output = output * scaling
                result = result + output
            return result

        def merge(self, safe_merge: bool = False, adapter_names: Optional[list[str]] = None) -> None:
            raise AttributeError("Merging LoRA layers is not supported for Eetq layers.")

        def unmerge(self) -> None:
            raise AttributeError("Unmerging LoRA layers is not supported for Eetq layers.")

        def __repr__(self) -> str:
            rep = super().__repr__()
            return "lora." + rep


def dispatch_eetq(
    target: torch.nn.Module,
    adapter_name: str,
    config: LoraConfig,
    **kwargs: Any,
) -> Optional[torch.nn.Module]:
    new_module = None

    if isinstance(target, BaseTunerLayer):
        target_base_layer = target.get_base_layer()
    else:
        target_base_layer = target

    if is_eetq_available() and isinstance(target_base_layer, eetq_classes):
        new_module = EetqLoraLinear(target, adapter_name, config=config, **kwargs)
        target.weight = target_base_layer.weight

        if hasattr(target, "bias"):
            target.bias = target_base_layer.bias

    return new_module
