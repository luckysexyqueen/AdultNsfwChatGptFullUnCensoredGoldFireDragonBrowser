<!--Copyright 2021 The HuggingFace Team. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
the License. You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
specific language governing permissions and limitations under the License.

⚠️ Note that this file is in Markdown but contain specific syntax for our doc-builder (similar to MDX) that may not be
rendered properly in your Markdown viewer.
-->

# Kwargs handlers

The following objects can be passed to the main [`Accelerator`] to customize how some PyTorch objects
related to distributed training or mixed precision are created.

## AutocastKwargs

[[autodoc]] AutocastKwargs

## DistributedDataParallelKwargs

[[autodoc]] DistributedDataParallelKwargs

## FP8RecipeKwargs

[[autodoc]] utils.FP8RecipeKwargs

## ProfileKwargs

[[autodoc]] utils.ProfileKwargs

## GradScalerKwargs

[[autodoc]] GradScalerKwargs

## InitProcessGroupKwargs

[[autodoc]] InitProcessGroupKwargs

## KwargsHandler

[[autodoc]] utils.KwargsHandler
