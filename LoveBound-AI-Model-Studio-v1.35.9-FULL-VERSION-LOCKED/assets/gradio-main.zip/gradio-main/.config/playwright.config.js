import { defineConfig, devices } from "@playwright/test";

const base = defineConfig({
	use: {
		screenshot: "only-on-failure",
		trace: "retain-on-failure",
		bypassCSP: true,
		launchOptions: {
			args: [
				"--disable-web-security",
				"--use-fake-device-for-media-stream",
				"--use-fake-ui-for-media-stream",
				"--use-file-for-fake-audio-capture=../gradio/test_data/test_audio.wav"
			]
		}
	},
	expect: { timeout: 10_000 },
	timeout: 30_000,
	testMatch: /.*\.spec\.ts/,
	testDir: "..",
	// Reload tests must stay serial (CUSTOM_TEST=1) — several rewrite a shared
	// `run.py` in the same cwd, so parallel workers would clobber each other.
	// For the regular browser suite on CI, allow PW_BROWSER_WORKERS to raise the
	// count above the historical default of 4 (the runner has 16 cores and the
	// tests are largely wait-bound, so they parallelize well).
	workers: process.env.CUSTOM_TEST
		? 1
		: process.env.CI
			? Number(process.env.PW_BROWSER_WORKERS) || 4
			: undefined,
	retries: 3,
	fullyParallel: false
});

// There are Firefox-specific issues such as https://github.com/gradio-app/gradio/pull/9528 so we want to run the tests on Firefox, but Firefox sometimes fails to start in the GitHub Actions environment so we disable it on CI.
const localOnly = (project) => (process.env.CI ? undefined : project);

const normal = defineConfig(base, {
	// globalSetup removed - each test file now launches its own Gradio app via fixture
	projects: [
		localOnly({
			name: "firefox",
			use: { ...devices["Desktop Firefox"] },
			grep: /@firefox/
		}),
		{
			name: "chrome",
			use: {
				...devices["Desktop Chrome"],
				permissions: ["clipboard-read", "clipboard-write", "microphone"]
			}
		}
	].filter(Boolean)
});

export default normal;
