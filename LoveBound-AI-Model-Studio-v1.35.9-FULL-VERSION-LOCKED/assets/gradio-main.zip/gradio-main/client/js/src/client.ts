import type {
	ApiData,
	ApiInfo,
	ClientOptions,
	Config,
	DuplicateOptions,
	EndpointInfo,
	JsApiData,
	PredictReturn,
	SpaceStatus,
	Status,
	UploadResponse,
	client_return,
	SubmitIterable,
	GradioEvent
} from "./types";
import { view_api } from "./utils/view_api";
import { upload_files } from "./utils/upload_files";
import { upload, FileData } from "./upload";
import { handle_blob } from "./utils/handle_blob";
import { post_data } from "./utils/post_data";
import { predict } from "./utils/predict";
import { duplicate } from "./utils/duplicate";
import { submit } from "./utils/submit";
import { RE_SPACE_NAME, process_endpoint } from "./helpers/api_info";
import {
	map_names_to_ids,
	normalise_token_option,
	resolve_cookies,
	resolve_config,
	get_jwt,
	parse_and_set_cookies
} from "./helpers/init_helpers";
import { check_and_wake_space, check_space_status } from "./helpers/spaces";
import { initialize_zerogpu_handshake } from "./helpers/zerogpu";
import { open_stream, readable_stream, close_stream } from "./utils/stream";
import { clear_run_history } from "./utils/run_history";
import { sign_config_file_urls, sign_file_urls } from "./helpers/data";
import {
	API_INFO_ERROR_MSG,
	APP_ID_URL,
	CONFIG_ERROR_MSG,
	HEARTBEAT_URL,
	COMPONENT_SERVER_URL
} from "./constants";
declare const BROWSER_BUILD: boolean;

export class Client {
	app_reference: string;
	options: ClientOptions;
	deep_link: string | null = null;
	page: string | null = null;

	config: Config | undefined;
	api_prefix = "";
	api_info: ApiInfo<JsApiData> | undefined;
	api_map: Record<string, number> = {};
	session_hash: string = Math.random().toString(36).substring(2);
	jwt: string | false = false;
	last_status: Record<string, Status["stage"]> = {};

	private cookies: string | null = null;

	// streaming
	stream_status = { open: false };
	closed = false;
	pending_stream_messages: Record<string, any[][]> = {};
	pending_diff_streams: Record<string, any[][]> = {};
	event_callbacks: Record<string, (data?: unknown) => Promise<void>> = {};
	unclosed_events: Set<string> = new Set();
	heartbeat_event: EventSource | null = null;
	heartbeat_controller: AbortController | null = null;
	// Outside a browser (e.g. Node, or SSR) a client is often connected only to
	// read its config, so the heartbeat waits for the first submit.
	heartbeat_wanted =
		typeof window !== "undefined" && typeof document !== "undefined";
	abort_controller: AbortController | null = null;
	stream_instance: EventSource | null = null;
	current_payload: any;

	get_url_config(url: string | null = null): Config {
		if (!this.config) {
			throw new Error(CONFIG_ERROR_MSG);
		}
		if (url === null) {
			url = window.location.href;
		}
		const stripSlashes = (str: string): string => str.replace(/^\/+|\/+$/g, "");
		let root_path = stripSlashes(new URL(this.config.root).pathname);
		let url_path = stripSlashes(new URL(url).pathname);
		let page: string;
		if (!url_path.startsWith(root_path)) {
			page = "";
		} else {
			page = stripSlashes(url_path.substring(root_path.length));
		}
		return this.get_page_config(page);
	}
	get_page_config(page: string): Config {
		if (!this.config) {
			throw new Error(CONFIG_ERROR_MSG);
		}
		let config = this.config;
		if (!(page in config.page)) {
			page = "";
		}
		return {
			...config,
			current_page: page,
			layout: config.page[page].layout,
			components: config.components.filter((c) =>
				config.page[page].components.includes(c.id)
			),
			dependencies: this.config.dependencies.filter((d) =>
				config.page[page].dependencies.includes(d.id)
			)
		};
	}

	fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
		const headers = new Headers(init?.headers || {});
		if (this && this.cookies) {
			headers.append("Cookie", this.cookies);
		}
		if (this && this.options.headers) {
			let additional_headers = new Headers(this.options.headers);

			additional_headers.forEach((value, name) => {
				headers.append(name, value);
			});
		}

		return fetch(input, { ...init, headers });
	}

	stream(url: URL, abort_controller?: AbortController): EventSource {
		const headers = new Headers();
		if (this && this.cookies) {
			headers.append("Cookie", this.cookies);
		}
		if (this && this.options.headers) {
			let additional_headers = new Headers(this.options.headers);

			additional_headers.forEach((value, name) => {
				headers.append(name, value);
			});
		}
		if (this && this.options.token) {
			headers.append("Authorization", `Bearer ${this.options.token}`);
		}

		if (!abort_controller) {
			abort_controller = new AbortController();
			this.abort_controller = abort_controller;
		}

		this.stream_instance = readable_stream(url.toString(), {
			credentials: this.options.credentials ?? "same-origin",
			headers: headers,
			signal: abort_controller.signal
		});

		return this.stream_instance;
	}

	view_api: () => Promise<ApiInfo<JsApiData>>;
	upload_files: (
		root_url: string,
		files: (Blob | File)[],
		upload_id?: string
	) => Promise<UploadResponse>;
	upload: (
		file_data: FileData[],
		root_url: string,
		upload_id?: string,
		max_file_size?: number
	) => Promise<(FileData | null)[] | null>;
	handle_blob: (
		endpoint: string,
		data: unknown[],
		endpoint_info: EndpointInfo<ApiData | JsApiData>
	) => Promise<unknown[]>;
	post_data: (
		url: string,
		body: unknown,
		additional_headers?: any
	) => Promise<unknown[]>;
	submit: (
		endpoint: string | number,
		data: unknown[] | Record<string, unknown> | undefined,
		event_data?: unknown,
		trigger_id?: number | null,
		all_events?: boolean
	) => SubmitIterable<GradioEvent>;
	predict: <T = unknown>(
		endpoint: string | number,
		data: unknown[] | Record<string, unknown> | undefined,
		event_data?: unknown
	) => Promise<PredictReturn<T>>;
	open_stream: () => Promise<void>;
	private resolve_config: (
		endpoint: string,
		strip_current_page?: boolean
	) => Promise<Config | undefined>;
	private resolve_cookies: () => Promise<void>;
	constructor(
		app_reference: string,
		options: ClientOptions = { events: ["data"] }
	) {
		this.app_reference = app_reference;
		this.deep_link = options.query_params?.deep_link || null;
		this.page = options.query_params?.page ?? null;
		if (!options.events) {
			options.events = ["data"];
		}
		normalise_token_option(options);

		this.options = options;
		this.current_payload = {};

		if (options.cookies) {
			this.cookies = options.cookies;
		}

		this.view_api = view_api.bind(this);
		this.upload_files = upload_files.bind(this);
		this.handle_blob = handle_blob.bind(this);
		this.post_data = post_data.bind(this);
		this.submit = submit.bind(this);
		this.predict = predict.bind(this) as typeof this.predict;
		this.open_stream = open_stream.bind(this);
		this.resolve_config = resolve_config.bind(this);
		this.resolve_cookies = resolve_cookies.bind(this);
		this.upload = upload.bind(this);
		this.fetch = this.fetch.bind(this);
		this.handle_space_success = this.handle_space_success.bind(this);
		this.stream = this.stream.bind(this);
	}

	private async init(): Promise<void> {
		initialize_zerogpu_handshake();

		if (this.options.auth) {
			await this.resolve_cookies();
		}

		await this._resolve_config().then(
			(res: { config: Config } | undefined) =>
				res?.config && this._resolve_heartbeat(res.config)
		);

		try {
			this.api_info = await this.view_api();
		} catch (e) {
			// A failure to fetch API info should not prevent the client from
			// connecting: otherwise the SSR server renders a spurious login
			// page whenever the /info endpoint is unreachable.
			console.error((e as Error).message);
		}
		this.api_map = map_names_to_ids(this.config?.dependencies || []);
	}

	async _resolve_heartbeat(_config: Config): Promise<void> {
		this.config = _config;
		this.api_prefix = _config.api_prefix || "";

		if (_config.space_id && this.options.token) {
			this.jwt = await get_jwt(
				_config.space_id,
				this.options.token,
				this.cookies
			);
		}

		sign_config_file_urls(this.config, this.jwt);

		if (this.heartbeat_wanted) {
			this.open_heartbeat();
		}
	}

	open_heartbeat(): void {
		this.heartbeat_wanted = true;
		if (!this.config?.connect_heartbeat || this.heartbeat_event) {
			return;
		}
		const heartbeat_url = new URL(
			`${this.config.root}${this.api_prefix}/${HEARTBEAT_URL}/${this.session_hash}`
		);

		if (this.jwt) {
			heartbeat_url.searchParams.set("__sign", this.jwt);
		}

		// Its own controller, so that close() still reaches it after other
		// streams have been opened. The response is not parsed. Ref: https://github.com/gradio-app/gradio/pull/7974#discussion_r1557717540
		this.heartbeat_controller = new AbortController();
		this.heartbeat_event = this.stream(
			heartbeat_url,
			this.heartbeat_controller
		);
	}

	static async connect(
		app_reference: string,
		options: ClientOptions = {
			events: ["data"]
		}
	): Promise<Client> {
		const client = new this(app_reference, options); // this refers to the class itself, not the instance
		if (options.session_hash) {
			client.session_hash = options.session_hash;
		}
		await client.init();
		return client;
	}

	async reconnect(): Promise<"connected" | "broken" | "changed"> {
		const app_id_url = new URL(
			`${this.config!.root}${this.api_prefix}/${APP_ID_URL}`
		);
		let app_id: string;
		try {
			const response = await this.fetch(app_id_url);
			if (!response.ok) {
				throw new Error();
			}
			app_id = ((await response.json()) as any).app_id;
		} catch (e) {
			return "broken";
		}
		if (app_id !== this.config!.app_id) {
			return "changed";
		}
		return "connected";
	}

	close(): void {
		this.closed = true;
		close_stream(this.stream_status, this.abort_controller);
		this.heartbeat_controller?.abort();
		this.heartbeat_controller = null;
		this.heartbeat_event = null;
	}

	/**
	 * Re-fetch the app config without closing the SSE stream.
	 * Used by hot-reload so in-flight generators keep delivering updates.
	 */
	async refresh(): Promise<Config> {
		if (!this.config) {
			throw new Error(CONFIG_ERROR_MSG);
		}
		// config.root is already the app root. resolve_config normally strips the
		// current page from its endpoint, which would strip one path segment too
		// many when refreshing from a subpage.
		const config = await this.resolve_config(this.config.root, false);
		if (!config) {
			throw new Error(CONFIG_ERROR_MSG);
		}
		this.config = config;
		this.api_prefix = config.api_prefix || "";
		this.api_map = map_names_to_ids(config.dependencies || []);
		sign_config_file_urls(this.config, this.jwt);
		try {
			this.api_info = await this.view_api();
		} catch (e) {
			console.error(API_INFO_ERROR_MSG + (e as Error).message);
		}
		return this.get_url_config();
	}

	set_current_payload(payload: any): void {
		this.current_payload = payload;
	}

	static async duplicate(
		app_reference: string,
		options: DuplicateOptions = {
			events: ["data"]
		}
	): Promise<Client> {
		return duplicate(app_reference, options);
	}

	private async _resolve_config(): Promise<any> {
		const { http_protocol, host, space_id } = await process_endpoint(
			this.app_reference,
			this.options.token
		);

		const { status_callback } = this.options;

		if (space_id && status_callback) {
			await check_and_wake_space(space_id, status_callback);
		}

		let config: Config | undefined;

		try {
			// Create base URL
			let configUrl = `${http_protocol}//${host}`;
			config = await this.resolve_config(configUrl);

			if (!config) {
				throw new Error(CONFIG_ERROR_MSG);
			}

			return this.config_success(config);
		} catch (e: any) {
			if (space_id && status_callback) {
				check_space_status(
					space_id,
					RE_SPACE_NAME.test(space_id) ? "space_name" : "subdomain",
					this.handle_space_success
				);
			} else {
				if (status_callback)
					status_callback({
						status: "error",
						message: "Could not load this space.",
						load_status: "error",
						detail: "NOT_FOUND"
					});
				throw e instanceof Error ? e : new Error(String(e));
			}
		}
	}

	private async config_success(
		_config: Config
	): Promise<Config | client_return> {
		this.config = _config;
		this.api_prefix = _config.api_prefix || "";

		// Opting out also purges, so an app that turns the feature off does not
		// leave behind what it stored while it was on.
		if (_config.run_history === false) {
			clear_run_history({
				app_id: _config.app_id,
				username: _config.username
			});
		}

		if (this.config.auth_required) {
			return this.prepare_return_obj();
		}

		try {
			this.api_info = await this.view_api();
		} catch (e) {
			console.error(API_INFO_ERROR_MSG + (e as Error).message);
		}

		return this.prepare_return_obj();
	}

	async handle_space_success(status: SpaceStatus): Promise<Config | void> {
		if (!this) {
			throw new Error(CONFIG_ERROR_MSG);
		}
		const { status_callback } = this.options;
		if (status_callback) status_callback(status);
		if (status.status === "running") {
			try {
				this.config = await this._resolve_config();
				this.api_prefix = this?.config?.api_prefix || "";

				if (!this.config) {
					throw new Error(CONFIG_ERROR_MSG);
				}

				const _config = await this.config_success(this.config);

				return _config as Config;
			} catch (e) {
				if (status_callback) {
					status_callback({
						status: "error",
						message: "Could not load this space.",
						load_status: "error",
						detail: "NOT_FOUND"
					});
				}
				throw e;
			}
		}
	}

	public async component_server(
		component_id: number,
		fn_name: string,
		data: unknown | { binary: boolean; data: Record<string, any> }
	): Promise<unknown> {
		if (!this.config) {
			throw new Error(CONFIG_ERROR_MSG);
		}

		const headers: {
			Authorization?: string;
			"Content-Type"?: "application/json";
		} = {};

		const { token } = this.options;
		const { session_hash } = this;

		if (token) {
			headers.Authorization = `Bearer ${this.options.token}`;
		}

		let root_url: string;
		let component = this.config.components.find(
			(comp) => comp.id === component_id
		);
		if (component?.props?.root_url) {
			root_url = component.props.root_url;
		} else {
			root_url = this.config.root;
		}

		let body: FormData | string;

		if (typeof data === "object" && data !== null && "binary" in data) {
			const _data = data as { binary: boolean; data: Record<string, any> };
			body = new FormData();
			for (const key in _data.data) {
				if (key === "binary") continue;
				body.append(key, _data.data[key]);
			}
			body.set("component_id", component_id.toString());
			body.set("fn_name", fn_name);
			body.set("session_hash", session_hash);
		} else {
			body = JSON.stringify({
				data: data,
				component_id,
				fn_name,
				session_hash
			});

			headers["Content-Type"] = "application/json";
		}

		if (token) {
			headers.Authorization = `Bearer ${token}`;
		}

		try {
			const response = await this.fetch(
				`${root_url}${this.api_prefix}/${COMPONENT_SERVER_URL}/`,
				{
					method: "POST",
					body: body,
					headers,
					credentials: this.options.credentials ?? "same-origin"
				}
			);

			if (!response.ok) {
				throw new Error(
					"Could not connect to component server: " + response.statusText
				);
			}

			const output = await response.json();
			sign_file_urls(
				output,
				this.config.root,
				this.config.api_prefix || "",
				this.jwt
			);
			return output;
		} catch (e) {
			console.warn(e);
		}
	}

	public set_cookies(raw_cookies: string): void {
		this.cookies = parse_and_set_cookies(raw_cookies).join("; ");
	}

	private prepare_return_obj(): client_return {
		return {
			config: this.config,
			predict: this.predict,
			submit: this.submit,
			view_api: this.view_api,
			component_server: this.component_server
		};
	}
}

/**
 * @deprecated This method will be removed in v1.0. Use `Client.connect()` instead.
 * Creates a client instance for interacting with Gradio apps.
 *
 * @param {string} app_reference - The reference or URL to a Gradio space or app.
 * @param {ClientOptions} options - Configuration options for the client.
 * @returns {Promise<Client>} A promise that resolves to a `Client` instance.
 */
export async function client(
	app_reference: string,
	options: ClientOptions = {
		events: ["data"]
	}
): Promise<Client> {
	return await Client.connect(app_reference, options);
}

/**
 * @deprecated This method will be removed in v1.0. Use `Client.duplicate()` instead.
 * Creates a duplicate of a space and returns a client instance for the duplicated space.
 *
 * @param {string} app_reference - The reference or URL to a Gradio space or app to duplicate.
 * @param {DuplicateOptions} options - Configuration options for the client.
 * @returns {Promise<Client>} A promise that resolves to a `Client` instance.
 */
export async function duplicate_space(
	app_reference: string,
	options: DuplicateOptions
): Promise<Client> {
	return await Client.duplicate(app_reference, options);
}

export type ClientInstance = Client;
