"""Tests for the FASTA file loader."""

import os

import pyarrow as pa
import pytest

from datasets import BioSequence, DatasetInfo, Features, Value, load_dataset
from datasets.builder import InvalidConfigName
from datasets.data_files import DataFilesList
from datasets.download.streaming_download_manager import _get_extraction_protocol
from datasets.packaged_modules.fasta.fasta import Fasta, FastaConfig
from datasets.utils.file_utils import xopen

from ..utils import require_zstandard


require_biopython = pytest.mark.skipif(
    not __import__("datasets").config.BIOPYTHON_AVAILABLE, reason="biopython is not installed"
)


def _compression_uri(path):
    """Build the chained fsspec URI datasets uses to read a single compressed file.

    The builder opens files with the streaming-patched ``open()`` (``xopen``), which
    handles compression via ``<protocol>://<inner>::<outer>`` URIs rather than by
    sniffing magic bytes. The protocol is derived from datasets' own extraction logic
    so the test tracks the loader's real behavior. ``inner`` is the decompressed name.
    """
    path = str(path)
    protocol = _get_extraction_protocol(path)
    inner = os.path.basename(path).rsplit(".", 1)[0]
    return f"{protocol}://{inner}::{path}"


# Sample FASTA content for inline fixtures
FASTA_CONTENT = """\
>seq1 Example protein sequence
MKWVTFISLLFLFSSAYSRGVFRRDTHKSEIAHRFKDLGEEHFKGLVLIAFSQYLQQCPF
EDHVKLVNEVTEFAKTCVADESHAGCEKSLHTLFGDELCKVASLRETYGDMADCCEKQEP
>seq2 Another sequence with multi-line
MVLSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTYFPHFDLSH
GSAQVKGHGKKVADALTNAVAHVDDMPNALSALSDLHAHKLRVDPVNFKLL
SHCLLVTLAAHLPAEFTPAVHASLDKFLASVSTVLTSKYR
>seq3
ATGCATGCATGCATGCATGCATGCATGC
"""


@pytest.fixture
def fasta_file(tmp_path):
    filename = tmp_path / "sequences.fasta"
    with open(filename, "w", encoding="utf-8", newline="") as f:
        f.write(FASTA_CONTENT)
    return str(filename)


@pytest.fixture
def fasta_file_fa(tmp_path):
    filename = tmp_path / "sequences.fa"
    with open(filename, "w", encoding="utf-8", newline="") as f:
        f.write(FASTA_CONTENT)
    return str(filename)


@pytest.fixture
def fasta_gz_file(tmp_path):
    import gzip

    filename = tmp_path / "sequences.fasta.gz"
    with gzip.open(filename, "wt", encoding="utf-8", newline="") as f:
        f.write(FASTA_CONTENT)
    return _compression_uri(filename)


@pytest.fixture
def fasta_bz2_file(tmp_path):
    import bz2

    filename = tmp_path / "sequences.fasta.bz2"
    with bz2.open(filename, "wt", encoding="utf-8", newline="") as f:
        f.write(FASTA_CONTENT)
    return _compression_uri(filename)


@pytest.fixture
def fasta_xz_file(tmp_path):
    import lzma

    filename = tmp_path / "sequences.fasta.xz"
    with lzma.open(filename, "wt", encoding="utf-8", newline="") as f:
        f.write(FASTA_CONTENT)
    return _compression_uri(filename)


@pytest.fixture
def fasta_zst_file(tmp_path):
    import zstandard

    filename = tmp_path / "sequences.fasta.zst"
    with open(filename, "wb") as f:
        f.write(zstandard.ZstdCompressor().compress(FASTA_CONTENT.encode("utf-8")))
    return _compression_uri(filename)


@pytest.fixture
def fasta_long_sequence_file(tmp_path):
    """Create a file with a very long sequence to test large_string handling."""
    filename = tmp_path / "long_sequence.fasta"
    long_seq = "ATGCATGCATGCATGC" * 1000  # 16KB sequence
    with open(filename, "w", encoding="utf-8", newline="") as f:
        f.write(f">long_seq Very long sequence\n{long_seq}\n")
    return str(filename)


@pytest.fixture
def fasta_empty_description_file(tmp_path):
    """Create a FASTA file with sequences that have no description."""
    filename = tmp_path / "no_description.fasta"
    content = """\
>seq1
ATGCATGC
>seq2
GCTAGCTA
"""
    with open(filename, "w", encoding="utf-8", newline="") as f:
        f.write(content)
    return str(filename)


def test_config_raises_when_invalid_name() -> None:
    with pytest.raises(InvalidConfigName, match="Bad characters"):
        _ = FastaConfig(name="name-with-*-invalid-character")


@pytest.mark.parametrize("data_files", ["str_path", ["str_path"], DataFilesList(["str_path"], [()])])
def test_config_raises_when_invalid_data_files(data_files) -> None:
    with pytest.raises(ValueError, match="Expected a DataFilesDict"):
        _ = FastaConfig(name="name", data_files=data_files)


def test_fasta_basic_loading(fasta_file):
    """Test basic FASTA file loading."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_file]])
    tables = list(generator)

    assert len(tables) == 1
    key, pa_table = tables[0]

    # Check columns
    assert pa_table.column_names == ["id", "description", "sequence", "record"]

    # Check data
    data = pa_table.to_pydict()
    assert data["id"] == ["seq1", "seq2", "seq3"]
    assert data["description"] == [
        "Example protein sequence",
        "Another sequence with multi-line",
        "",
    ]
    # Sequences should be concatenated (multi-line merged)
    assert data["sequence"][0] == (
        "MKWVTFISLLFLFSSAYSRGVFRRDTHKSEIAHRFKDLGEEHFKGLVLIAFSQYLQQCPF"
        "EDHVKLVNEVTEFAKTCVADESHAGCEKSLHTLFGDELCKVASLRETYGDMADCCEKQEP"
    )
    assert data["sequence"][2] == "ATGCATGCATGCATGCATGCATGCATGC"


def test_fasta_fa_extension(fasta_file_fa):
    """Test loading with .fa extension."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_file_fa]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    assert pa_table.num_rows == 3


def test_fasta_afa_extension(tmp_path):
    """Test that .afa (aligned FASTA) files are recognized and loaded."""
    from datasets.packaged_modules import _EXTENSION_TO_MODULE

    # .afa routes to the FASTA builder in auto-detection and is a supported extension
    assert _EXTENSION_TO_MODULE.get(".afa") == ("fasta", {})
    assert ".afa" in Fasta.EXTENSIONS

    filename = tmp_path / "alignment.afa"
    with open(filename, "w", encoding="utf-8", newline="") as f:
        f.write(FASTA_CONTENT)

    fasta = Fasta()
    tables = list(fasta._generate_tables([[str(filename)]]))
    assert len(tables) == 1
    _, pa_table = tables[0]
    assert pa_table.num_rows == 3


def test_fasta_gzip_compression(fasta_gz_file):
    """Test loading gzipped FASTA files."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_gz_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    data = pa_table.to_pydict()
    assert data["id"] == ["seq1", "seq2", "seq3"]


def test_fasta_bz2_compression(fasta_bz2_file):
    """Test loading bz2-compressed FASTA files."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_bz2_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    data = pa_table.to_pydict()
    assert data["id"] == ["seq1", "seq2", "seq3"]


def test_fasta_xz_compression(fasta_xz_file):
    """Test loading xz-compressed FASTA files."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_xz_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    data = pa_table.to_pydict()
    assert data["id"] == ["seq1", "seq2", "seq3"]


@require_zstandard
def test_fasta_zstd_compression(fasta_zst_file):
    """Test loading zstd-compressed FASTA files, which is common for large FASTA data."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_zst_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    data = pa_table.to_pydict()
    assert data["id"] == ["seq1", "seq2", "seq3"]


def test_fasta_long_sequence(fasta_long_sequence_file):
    """Test handling of very long sequences with large_string type."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_long_sequence_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]

    # Check that sequence column uses large_string type
    assert pa_table.schema.field("sequence").type == pa.large_string()

    data = pa_table.to_pydict()
    expected_length = len("ATGCATGCATGCATGC" * 1000)
    assert len(data["sequence"][0]) == expected_length


def test_fasta_column_filtering(fasta_file):
    """Test loading only specific columns."""
    fasta = Fasta(columns=["id", "sequence"])
    generator = fasta._generate_tables([[fasta_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]

    # Only selected columns should be present
    assert pa_table.column_names == ["id", "sequence"]
    data = pa_table.to_pydict()
    assert "description" not in data


def test_fasta_sequence_only(fasta_file):
    """Test loading only the sequence column."""
    fasta = Fasta(columns=["sequence"])
    generator = fasta._generate_tables([[fasta_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    assert pa_table.column_names == ["sequence"]


def test_fasta_invalid_column():
    """Test that invalid column names raise an error."""
    with pytest.raises(ValueError, match="Invalid column"):
        fasta = Fasta(columns=["invalid_column"])
        list(fasta._generate_tables([[]]))


def test_fasta_batch_size(fasta_file):
    """Test batch size configuration."""
    fasta = Fasta(batch_size=1)
    generator = fasta._generate_tables([[fasta_file]])
    tables = list(generator)

    # With batch_size=1, we should get 3 separate tables
    assert len(tables) == 3
    for _, pa_table in tables:
        assert pa_table.num_rows == 1


def test_fasta_empty_description(fasta_empty_description_file):
    """Test sequences with no description."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_empty_description_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    data = pa_table.to_pydict()
    assert data["description"] == ["", ""]


def test_fasta_schema_types(fasta_file):
    """Test that the Arrow schema has correct types."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_file]])
    tables = list(generator)

    _, pa_table = tables[0]
    schema = pa_table.schema

    # id and description should be string
    assert schema.field("id").type == pa.string()
    assert schema.field("description").type == pa.string()
    # sequence should be large_string to handle long sequences
    assert schema.field("sequence").type == pa.large_string()


def test_fasta_feature_casting(fasta_file):
    """Test custom feature casting."""
    features = Features(
        {
            "id": Value("string"),
            "sequence": Value("large_string"),
        }
    )
    fasta = Fasta(columns=["id", "sequence"], features=features)
    generator = fasta._generate_tables([[fasta_file]])
    tables = list(generator)

    assert len(tables) == 1
    _, pa_table = tables[0]
    assert pa_table.num_rows == 3


def test_fasta_multiple_files(fasta_file, fasta_file_fa):
    """Test loading multiple FASTA files."""
    fasta = Fasta()
    generator = fasta._generate_tables([[fasta_file], [fasta_file_fa]])
    tables = list(generator)

    # Should get one batch from each file
    assert len(tables) == 2

    total_rows = sum(pa_table.num_rows for _, pa_table in tables)
    assert total_rows == 6  # 3 sequences per file * 2 files


def test_fasta_max_batch_bytes(tmp_path):
    """Test byte-based batching for handling large sequences.

    This tests the adaptive batching that prevents Parquet page size errors
    when dealing with very large sequences (e.g., complete genomes).
    """
    # Create sequences of known sizes
    # Each sequence is ~100 bytes (id + description + sequence)
    filename = tmp_path / "batch_test.fasta"
    with open(filename, "w", encoding="utf-8", newline="") as f:
        for i in range(5):
            seq = "A" * 80  # 80 byte sequence
            f.write(f">seq{i} description{i}\n{seq}\n")

    # With max_batch_bytes=200, we should get multiple batches
    # Each record is ~100 bytes, so ~2 records per batch
    fasta = Fasta(batch_size=10000, max_batch_bytes=200)
    generator = fasta._generate_tables([[str(filename)]])
    tables = list(generator)

    # Should have multiple batches due to byte limit
    assert len(tables) >= 2

    # Total rows should still be 5
    total_rows = sum(pa_table.num_rows for _, pa_table in tables)
    assert total_rows == 5


def test_fasta_max_batch_bytes_disabled(tmp_path):
    """Test that max_batch_bytes=None disables byte-based batching."""
    filename = tmp_path / "large_seqs.fasta"
    # Create 3 sequences with 1KB each
    with open(filename, "w", encoding="utf-8", newline="") as f:
        for i in range(3):
            seq = "ATGC" * 256  # 1KB sequence
            f.write(f">seq{i}\n{seq}\n")

    # With max_batch_bytes=None, only batch_size matters
    fasta = Fasta(batch_size=10000, max_batch_bytes=None)
    generator = fasta._generate_tables([[str(filename)]])
    tables = list(generator)

    # Should be single batch since batch_size is large and byte limit is disabled
    assert len(tables) == 1
    _, pa_table = tables[0]
    assert pa_table.num_rows == 3


def test_fasta_large_genome_batching(tmp_path):
    """Test handling of genome-scale sequences that would exceed Parquet page limits.

    This simulates the scenario described in PR #7851 where very large sequences
    (e.g., viral genomes of 30KB+) could cause Parquet page size errors.
    """
    filename = tmp_path / "genome.fasta"
    # Create a "genome" of 50KB - this would cause issues without byte-based batching
    genome_seq = "ATGCGTACGT" * 5000  # 50KB sequence

    with open(filename, "w", encoding="utf-8", newline="") as f:
        f.write(f">genome1 Large viral genome\n{genome_seq}\n")
        f.write(f">genome2 Another large genome\n{genome_seq}\n")

    # With small max_batch_bytes, each genome should be in its own batch
    fasta = Fasta(batch_size=10000, max_batch_bytes=60000)  # 60KB limit
    generator = fasta._generate_tables([[str(filename)]])
    tables = list(generator)

    # Each 50KB genome should be in separate batch
    assert len(tables) == 2

    for _, pa_table in tables:
        assert pa_table.num_rows == 1
        data = pa_table.to_pydict()
        assert len(data["sequence"][0]) == 50000


def test_fasta_default_max_batch_bytes():
    """Test that default max_batch_bytes is set correctly."""
    from datasets.packaged_modules.fasta.fasta import DEFAULT_MAX_BATCH_BYTES

    # Default should be 256MB
    assert DEFAULT_MAX_BATCH_BYTES == 256 * 1024 * 1024

    # Config should use this default
    config = FastaConfig(name="test")
    assert config.max_batch_bytes == DEFAULT_MAX_BATCH_BYTES


def test_fasta_parser_drops_whitespace_inside_sequence_lines():
    """Whitespace inside a sequence line is not sequence (Biopython: ''.join(lines).replace(' ', ''))."""
    import io

    assert list(Fasta()._parse_fasta(io.StringIO(">a\nA C-G*\nT T\n"))) == [("a", "", "AC-G*TT")]


def test_fasta_parser_skips_semicolon_comment_lines():
    """Pearson FASTA defines lines starting with ';' as comments, not sequence."""
    import io

    assert list(Fasta()._parse_fasta(io.StringIO(";file comment\n>a\n; record comment\nACGT\n"))) == [
        ("a", "", "ACGT")
    ]


def test_fasta_empty_columns_is_rejected():
    with pytest.raises(ValueError, match="at least one column"):
        Fasta(columns=[])._get_columns()


@pytest.mark.parametrize("features", [None, Features({"id": Value("string")})])
def test_fasta_duplicate_columns_is_rejected(features):
    with pytest.raises(ValueError, match="Duplicate column 'id'"):
        Fasta(columns=["id", "id"], features=features)


def test_fasta_columns_project_custom_features(tmp_path):
    """columns= applies to a user-supplied features schema too."""
    filename = tmp_path / "proj.fa"
    filename.write_bytes(b">a\nAC\n")
    features = Features({col: Value("string") for col in ["id", "description", "sequence"]})
    fasta = Fasta(columns=["sequence"], features=features)
    assert fasta.info.features == Features({"sequence": Value("string")})
    table = next(iter(fasta._generate_tables([[str(filename)]])))[1]
    assert table.column_names == ["sequence"]
    assert Features.from_arrow_schema(table.schema) == fasta.info.features
    with pytest.raises(ValueError, match="not in features"):
        Fasta(columns=["sequence"], features=Features({"id": Value("string")}))._info()


@pytest.mark.parametrize("columns", [None, ["record"]])
def test_fasta_preserves_supplied_info_features(fasta_file, columns):
    features = Features(
        {
            "id": Value("string"),
            "description": Value("string"),
            "sequence": Value("large_string"),
            "record": BioSequence(format="fasta", decode=False),
        }
    )
    fasta = Fasta(info=DatasetInfo(features=features, description="custom info"), columns=columns)
    expected = features if columns is None else Features({"record": features["record"]})
    assert fasta.info.features == expected
    assert fasta.info.description == "custom info"
    _, table = next(fasta._generate_tables([[fasta_file]]))
    assert Features.from_arrow_schema(table.schema) == expected


def test_fasta_record_features(fasta_file):
    fasta = Fasta()
    expected = Features(
        {
            "id": Value("string"),
            "description": Value("string"),
            "sequence": Value("large_string"),
            "record": BioSequence(format="fasta"),
        }
    )
    assert fasta.info.features == expected
    _, table = next(fasta._generate_tables([[fasta_file]]))
    assert table.schema.field("record").type == BioSequence().pa_type
    assert Features.from_arrow_schema(table.schema) == expected


@require_biopython
@pytest.mark.parametrize("streaming", [False, True])
def test_fasta_record_decoding(fasta_file, streaming):
    from Bio.SeqRecord import SeqRecord

    dataset = load_dataset("fasta", data_files=fasta_file, split="train", streaming=streaming)
    assert dataset.features["record"] == BioSequence(format="fasta")
    rows = list(dataset)
    assert len(rows) == 3
    for row in rows:
        assert isinstance(row["record"], SeqRecord)
        assert row["record"].id == row["id"]
        assert str(row["record"].seq) == row["sequence"]


@pytest.mark.parametrize(
    "fixture_name",
    [
        "fasta_file",
        "fasta_gz_file",
        "fasta_bz2_file",
        "fasta_xz_file",
        pytest.param("fasta_zst_file", marks=require_zstandard),
    ],
)
def test_fasta_record_bytes(fixture_name, request):
    filename = request.getfixturevalue(fixture_name)
    tables = list(Fasta(batch_size=1)._generate_tables([[filename]]))
    records = [table.to_pydict()["record"][0] for _, table in tables]
    with xopen(filename, "rb") as f:
        expected = [b">" + record for record in f.read().split(b">")[1:]]
    assert records == [{"bytes": record, "path": None} for record in expected]


@pytest.mark.parametrize("newline", [b"\n", b"\r\n", b"\r"])
@pytest.mark.parametrize("compressed", [False, True])
def test_fasta_record_preserves_raw_lines(tmp_path, newline, compressed):
    import gzip

    # Preserve header whitespace, UTF-8, comments, blank lines and sequence wrapping.
    first = b">a caf\xc3\xa9 \t\n; comment\nA C\n\nGT  \n".replace(b"\n", newline)
    second = b">b\nTT\nAA".replace(b"\n", newline)
    content = b"; file comment" + newline + first + second
    filename = tmp_path / ("raw.fa.gz" if compressed else "raw.fa")
    filename.write_bytes(gzip.compress(content) if compressed else content)
    path = _compression_uri(filename) if compressed else str(filename)
    _, table = next(Fasta(columns=["record"])._generate_tables([[path]]))
    assert table.to_pydict() == {"record": [{"bytes": first, "path": None}, {"bytes": second, "path": None}]}


def test_fasta_record_cast_decode_false(fasta_file, monkeypatch):
    monkeypatch.setattr("datasets.config.BIOPYTHON_AVAILABLE", False)
    dataset = load_dataset("fasta", data_files=fasta_file, split="train")
    dataset = dataset.cast_column("record", BioSequence(decode=False))
    with open(fasta_file, "rb") as f:
        expected = [b">" + record for record in f.read().split(b">")[1:]]
    assert dataset["record"] == [{"bytes": record, "path": None} for record in expected]


def test_fasta_columns_drop_record_without_biopython(fasta_file, monkeypatch):
    monkeypatch.setattr("datasets.config.BIOPYTHON_AVAILABLE", False)
    dataset = load_dataset("fasta", data_files=fasta_file, split="train", columns=["id", "sequence"])
    assert dataset.features == Features({"id": Value("string"), "sequence": Value("large_string")})
    assert len(list(dataset)) == 3
    assert dataset.column_names == ["id", "sequence"]


def test_fasta_record_column_validation():
    with pytest.raises(ValueError, match="Invalid column.*Valid columns are:.*record"):
        Fasta(columns=["invalid_column"])._get_columns()
    with pytest.raises(ValueError, match="columns.*record.*not in features"):
        Fasta(columns=["record"], features=Features({"id": Value("string")}))


def test_fasta_record_bytes_count_toward_batch_limit(tmp_path):
    filename = tmp_path / "batch.fa"
    # Parsed fields fit in one batch; their raw records push the total over the limit.
    filename.write_bytes(b">a\nACGT\n>b\nTGCA\n")
    tables = list(Fasta(max_batch_bytes=20)._generate_tables([[str(filename)]]))
    assert [table.num_rows for _, table in tables] == [1, 1]
    tables = list(Fasta(columns=["id", "sequence"], max_batch_bytes=20)._generate_tables([[str(filename)]]))
    assert [table.num_rows for _, table in tables] == [2]


def test_fasta_explicit_features_without_record(fasta_file):
    """A user-supplied schema selects its own columns, so pinning the three parsed columns still works."""
    features = Features(
        {
            "id": Value("string"),
            "description": Value("string"),
            "sequence": Value("large_string"),
        }
    )
    fasta = Fasta(features=features)
    assert fasta._get_columns() == ["id", "description", "sequence"]
    assert fasta.info.features == features
    generator = fasta._generate_tables([[fasta_file]])
    table = pa.concat_tables([table for _, table in generator])
    assert table.column_names == ["id", "description", "sequence"]
    with pytest.raises(ValueError, match="Invalid feature column"):
        Fasta(features=Features({"id": Value("string"), "quality": Value("string")}))
