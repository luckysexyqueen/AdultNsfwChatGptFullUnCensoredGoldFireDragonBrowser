import json
import pickle
import struct
from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import Mock

import pytest
from pytest_mock import MockerFixture

from huggingface_hub import constants
from huggingface_hub.serialization import (
    get_torch_storage_size,
    load_state_dict_from_file,
    load_torch_model,
    save_torch_model,
    save_torch_state_dict,
    split_state_dict_into_shards_factory,
    split_torch_state_dict_into_shards,
)
from huggingface_hub.serialization._base import parse_size_to_int
from huggingface_hub.serialization._torch import _is_safetensors, _load_sharded_checkpoint
from huggingface_hub.utils import is_torch_available


if TYPE_CHECKING:
    import torch


def _dummy_get_storage_id(item):
    return None


def _dummy_get_storage_size(item):
    return sum(item)


# util functions for checking the version for pytorch
def is_wrapper_tensor_subclass_available():
    try:
        from torch.utils._python_dispatch import is_traceable_wrapper_subclass  # type: ignore[import] # noqa: F401

        return True
    except ImportError:
        return False


def is_dtensor_available():
    try:
        from torch.distributed.device_mesh import init_device_mesh  # type: ignore[import] # noqa: F401
        from torch.distributed.tensor import DTensor  # type: ignore[import] # noqa: F401

        return True
    except ImportError:
        return False


@pytest.fixture
def dummy_state_dict() -> dict[str, list[int]]:
    return {
        "layer_1": [6],
        "layer_2": [10],
        "layer_3": [30],
        "layer_4": [2],
        "layer_5": [2],
    }


@pytest.fixture
def torch_state_dict() -> dict[str, "torch.Tensor"]:
    try:
        import torch

        return {
            "layer_1": torch.tensor([4]),
            "layer_2": torch.tensor([10]),
            "layer_3": torch.tensor([30]),
            "layer_4": torch.tensor([2]),
            "layer_5": torch.tensor([2]),
        }
    except ImportError:
        pytest.skip("torch is not available")


@pytest.fixture
def dummy_model():
    try:
        import torch

        class DummyModel(torch.nn.Module):
            """Simple model for testing that matches the state dict `torch_state_dict` fixture."""

            def __init__(self):
                super().__init__()
                self.register_parameter("layer_1", torch.nn.Parameter(torch.tensor([4.0])))
                self.register_parameter("layer_2", torch.nn.Parameter(torch.tensor([10.0])))
                self.register_parameter("layer_3", torch.nn.Parameter(torch.tensor([30.0])))
                self.register_parameter("layer_4", torch.nn.Parameter(torch.tensor([2.0])))
                self.register_parameter("layer_5", torch.nn.Parameter(torch.tensor([2.0])))

        return DummyModel()
    except ImportError:
        pytest.skip("torch is not available")


@pytest.fixture
def torch_state_dict_tensor_subclass() -> dict[str, "torch.Tensor"]:
    try:
        import torch  # type: ignore[import]
        from torch.testing._internal.two_tensor import TwoTensor  # type: ignore[import]

        t = torch.tensor([4])
        return {
            "layer_1": torch.tensor([4]),
            "layer_2": torch.tensor([10]),
            "layer_3": torch.tensor([30]),
            "layer_4": torch.tensor([2]),
            "layer_5": torch.tensor([2]),
            "layer_6": TwoTensor(t, t),
        }
    except ImportError:
        pytest.skip("torch is not available")


@pytest.fixture
def torch_state_dict_shared_layers() -> dict[str, "torch.Tensor"]:
    try:
        import torch  # type: ignore[import]

        shared_layer = torch.tensor([4])

        return {
            "shared_1": shared_layer,
            "unique_1": torch.tensor([10]),
            "unique_2": torch.tensor([30]),
            "shared_2": shared_layer,
        }
    except ImportError:
        pytest.skip("torch is not available")


@pytest.fixture
def torch_state_dict_shared_layers_tensor_subclass() -> dict[str, "torch.Tensor"]:
    try:
        import torch  # type: ignore[import]
        from torch.testing._internal.two_tensor import TwoTensor  # type: ignore[import]

        t = torch.tensor([4])
        tensor_subclass_tensor = TwoTensor(t, t)

        t = torch.tensor([4])
        shared_tensor_subclass_tensor = TwoTensor(t, t)
        return {
            "layer_1": torch.tensor([4]),
            "layer_2": torch.tensor([10]),
            "layer_3": torch.tensor([30]),
            "layer_4": torch.tensor([2]),
            "layer_5": torch.tensor([2]),
            "layer_6": tensor_subclass_tensor,
            "ts_shared_1": shared_tensor_subclass_tensor,
            "ts_shared_2": shared_tensor_subclass_tensor,
        }
    except ImportError:
        pytest.skip("torch is not available")


def test_single_shard(dummy_state_dict):
    state_dict_split = split_state_dict_into_shards_factory(
        dummy_state_dict,
        get_storage_id=_dummy_get_storage_id,
        get_storage_size=_dummy_get_storage_size,
        max_shard_size=100,  # large shard size => only one shard
        filename_pattern="file{suffix}.dummy",
    )
    assert not state_dict_split.is_sharded
    assert state_dict_split.filename_to_tensors == {
        # All layers fit in one shard => no suffix in filename
        "file.dummy": ["layer_1", "layer_2", "layer_3", "layer_4", "layer_5"],
    }
    assert state_dict_split.tensor_to_filename == {
        "layer_1": "file.dummy",
        "layer_2": "file.dummy",
        "layer_3": "file.dummy",
        "layer_4": "file.dummy",
        "layer_5": "file.dummy",
    }
    assert state_dict_split.metadata == {"total_size": 50}


def test_multiple_shards(dummy_state_dict):
    state_dict_split = split_state_dict_into_shards_factory(
        dummy_state_dict,
        get_storage_id=_dummy_get_storage_id,
        get_storage_size=_dummy_get_storage_size,
        max_shard_size=10,  # small shard size => multiple shards
        filename_pattern="file{suffix}.dummy",
    )

    assert state_dict_split.is_sharded
    assert state_dict_split.filename_to_tensors == {
        # layer 4 and 5 could go in this one but assignment is not optimal, and it's fine
        "file-00001-of-00004.dummy": ["layer_1"],
        "file-00002-of-00004.dummy": ["layer_3"],
        "file-00003-of-00004.dummy": ["layer_2"],
        "file-00004-of-00004.dummy": ["layer_4", "layer_5"],
    }
    assert state_dict_split.tensor_to_filename == {
        "layer_1": "file-00001-of-00004.dummy",
        "layer_3": "file-00002-of-00004.dummy",
        "layer_2": "file-00003-of-00004.dummy",
        "layer_4": "file-00004-of-00004.dummy",
        "layer_5": "file-00004-of-00004.dummy",
    }
    assert state_dict_split.metadata == {"total_size": 50}


def test_tensor_same_storage():
    state_dict_split = split_state_dict_into_shards_factory(
        {
            "layer_1": [1],
            "layer_2": [2],
            "layer_3": [1],
            "layer_4": [2],
            "layer_5": [1],
        },
        get_storage_id=lambda x: x[0],  # dummy for test: storage id based on first element
        get_storage_size=_dummy_get_storage_size,
        max_shard_size=1,
        filename_pattern="model{suffix}.safetensors",
    )
    assert state_dict_split.is_sharded
    assert state_dict_split.filename_to_tensors == {
        "model-00001-of-00002.safetensors": ["layer_2", "layer_4"],
        "model-00002-of-00002.safetensors": ["layer_1", "layer_3", "layer_5"],
    }
    assert state_dict_split.tensor_to_filename == {
        "layer_1": "model-00002-of-00002.safetensors",
        "layer_2": "model-00001-of-00002.safetensors",
        "layer_3": "model-00002-of-00002.safetensors",
        "layer_4": "model-00001-of-00002.safetensors",
        "layer_5": "model-00002-of-00002.safetensors",
    }
    assert state_dict_split.metadata == {"total_size": 3}  # count them once


def test_single_shard_skips_string_tensors():
    # String values can appear in a state dict when bnb serialization is used (see
    # https://github.com/huggingface/transformers/pull/24416). They are skipped when building
    # shards, so they must also be absent from the single-shard index, consistently with the
    # multi-shard path.
    state_dict_split = split_state_dict_into_shards_factory(
        {
            "layer_1": [6],
            "bnb_string": "quantization_metadata",  # skipped, must not appear in the index
            "layer_2": [10],
        },
        get_storage_id=_dummy_get_storage_id,
        get_storage_size=_dummy_get_storage_size,
        max_shard_size=100,  # large shard size => only one shard
        filename_pattern="file{suffix}.dummy",
    )
    assert not state_dict_split.is_sharded
    assert state_dict_split.filename_to_tensors == {"file.dummy": ["layer_1", "layer_2"]}
    assert state_dict_split.tensor_to_filename == {"layer_1": "file.dummy", "layer_2": "file.dummy"}
    assert state_dict_split.metadata == {"total_size": 16}


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_get_torch_storage_size():
    import torch  # type: ignore[import]

    assert get_torch_storage_size(torch.tensor([1, 2, 3, 4, 5], dtype=torch.float64)) == 5 * 8
    assert get_torch_storage_size(torch.tensor([1, 2, 3, 4, 5], dtype=torch.float16)) == 5 * 2


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
@pytest.mark.skipif(not is_dtensor_available(), reason="requires torch with dtensor available")
def test_get_torch_storage_size_dtensor():
    # testing distributed sharded tensors isn't very easy, would need to subprocess call torchrun, so this should be good enough
    import torch
    import torch.distributed as dist
    from torch.distributed.device_mesh import init_device_mesh
    from torch.distributed.tensor import DTensor, Replicate

    if dist.is_available() and not dist.is_initialized():
        dist.init_process_group(
            backend="gloo",
            store=dist.HashStore(),
            rank=0,
            world_size=1,
        )

    mesh = init_device_mesh("cpu", (1,))
    local = torch.tensor([1, 2, 3, 4, 5], dtype=torch.float16)
    dt = DTensor.from_local(local, mesh, [Replicate()])

    assert get_torch_storage_size(dt) == 5 * 2

    if dist.is_initialized():
        dist.destroy_process_group()


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
@pytest.mark.skipif(not is_wrapper_tensor_subclass_available(), reason="requires torch 2.1 or higher")
def test_get_torch_storage_size_wrapper_tensor_subclass():
    import torch  # type: ignore[import]
    from torch.testing._internal.two_tensor import TwoTensor  # type: ignore[import]

    t = torch.tensor([1, 2, 3, 4, 5], dtype=torch.float64)
    assert get_torch_storage_size(TwoTensor(t, t)) == 5 * 8 * 2
    t = torch.tensor([1, 2, 3, 4, 5], dtype=torch.float16)
    assert get_torch_storage_size(TwoTensor(t, TwoTensor(t, t))) == 5 * 2 * 3


def test_parse_size_to_int():
    assert parse_size_to_int("1KB") == 1 * 10**3
    assert parse_size_to_int("2MB") == 2 * 10**6
    assert parse_size_to_int("3GB") == 3 * 10**9
    assert parse_size_to_int(" 10 KB ") == 10 * 10**3  # ok with whitespace
    assert parse_size_to_int("20mb") == 20 * 10**6  # ok with lowercase

    with pytest.raises(ValueError, match="Unit 'IB' not supported"):
        parse_size_to_int("1KiB")  # not a valid unit

    with pytest.raises(ValueError, match="Could not parse the size value"):
        parse_size_to_int("1ooKB")  # not a float


def test_save_torch_model(mocker: MockerFixture, tmp_path: Path) -> None:
    """Test `save_torch_model` is only a wrapper around `save_torch_state_dict`."""
    model_mock = Mock()
    safe_state_dict_mock = mocker.patch("huggingface_hub.serialization._torch.save_torch_state_dict")
    save_torch_model(
        model_mock,
        save_directory=tmp_path,
        filename_pattern="my-pattern",
        force_contiguous=True,
        max_shard_size="3GB",
        metadata={"foo": "bar"},
        safe_serialization=True,
        is_main_process=True,
        shared_tensors_to_discard=None,
    )
    safe_state_dict_mock.assert_called_once_with(
        state_dict=model_mock.state_dict.return_value,
        save_directory=tmp_path,
        filename_pattern="my-pattern",
        force_contiguous=True,
        max_shard_size="3GB",
        metadata={"foo": "bar"},
        safe_serialization=True,
        is_main_process=True,
        shared_tensors_to_discard=None,
    )


def test_save_torch_state_dict_not_sharded(tmp_path: Path, torch_state_dict: dict[str, "torch.Tensor"]) -> None:
    """Save as safetensors without sharding."""
    save_torch_state_dict(torch_state_dict, tmp_path, max_shard_size="1GB")
    assert (tmp_path / "model.safetensors").is_file()
    assert not (tmp_path / "model.safetensors.index.json").is_file()


def test_save_torch_state_dict_sharded(tmp_path: Path, torch_state_dict: dict[str, "torch.Tensor"]) -> None:
    """Save as safetensors with sharding."""
    save_torch_state_dict(torch_state_dict, tmp_path, max_shard_size=30)
    assert not (tmp_path / "model.safetensors").is_file()
    assert (tmp_path / "model.safetensors.index.json").is_file()
    assert (tmp_path / "model-00001-of-00002.safetensors").is_file()
    assert (tmp_path / "model-00001-of-00002.safetensors").is_file()

    assert json.loads((tmp_path / "model.safetensors.index.json").read_text("utf-8")) == {
        "metadata": {"total_size": 40},
        "weight_map": {
            "layer_1": "model-00001-of-00002.safetensors",
            "layer_2": "model-00001-of-00002.safetensors",
            "layer_3": "model-00001-of-00002.safetensors",
            "layer_4": "model-00002-of-00002.safetensors",
            "layer_5": "model-00002-of-00002.safetensors",
        },
    }


def test_save_torch_state_dict_unsafe_not_sharded(
    tmp_path: Path, caplog: pytest.LogCaptureFixture, torch_state_dict: dict[str, "torch.Tensor"]
) -> None:
    """Save as pickle without sharding."""
    with caplog.at_level("WARNING"):
        save_torch_state_dict(torch_state_dict, tmp_path, max_shard_size="1GB", safe_serialization=False)
    assert "we strongly recommend using safe serialization" in caplog.text

    assert (tmp_path / "pytorch_model.bin").is_file()
    assert not (tmp_path / "pytorch_model.bin.index.json").is_file()


@pytest.mark.skipif(not is_wrapper_tensor_subclass_available(), reason="requires torch 2.1 or higher")
def test_save_torch_state_dict_tensor_subclass_unsafe_not_sharded(
    tmp_path: Path, caplog: pytest.LogCaptureFixture, torch_state_dict_tensor_subclass: dict[str, "torch.Tensor"]
) -> None:
    """Save as pickle without sharding."""
    with caplog.at_level("WARNING"):
        save_torch_state_dict(
            torch_state_dict_tensor_subclass, tmp_path, max_shard_size="1GB", safe_serialization=False
        )
    assert "we strongly recommend using safe serialization" in caplog.text

    assert (tmp_path / "pytorch_model.bin").is_file()
    assert not (tmp_path / "pytorch_model.bin.index.json").is_file()


@pytest.mark.skipif(not is_wrapper_tensor_subclass_available(), reason="requires torch 2.1 or higher")
def test_save_torch_state_dict_shared_layers_tensor_subclass_unsafe_not_sharded(
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
    torch_state_dict_shared_layers_tensor_subclass: dict[str, "torch.Tensor"],
) -> None:
    """Save as pickle without sharding."""
    with caplog.at_level("WARNING"):
        save_torch_state_dict(
            torch_state_dict_shared_layers_tensor_subclass, tmp_path, max_shard_size="1GB", safe_serialization=False
        )
    assert "we strongly recommend using safe serialization" in caplog.text

    assert (tmp_path / "pytorch_model.bin").is_file()
    assert not (tmp_path / "pytorch_model.bin.index.json").is_file()


def test_save_torch_state_dict_unsafe_sharded(
    tmp_path: Path, caplog: pytest.LogCaptureFixture, torch_state_dict: dict[str, "torch.Tensor"]
) -> None:
    """Save as pickle with sharding."""
    # Check logs
    with caplog.at_level("WARNING"):
        save_torch_state_dict(torch_state_dict, tmp_path, max_shard_size=30, safe_serialization=False)
    assert "we strongly recommend using safe serialization" in caplog.text

    assert not (tmp_path / "pytorch_model.bin").is_file()
    assert (tmp_path / "pytorch_model.bin.index.json").is_file()
    assert (tmp_path / "pytorch_model-00001-of-00002.bin").is_file()
    assert (tmp_path / "pytorch_model-00001-of-00002.bin").is_file()

    assert json.loads((tmp_path / "pytorch_model.bin.index.json").read_text("utf-8")) == {
        "metadata": {"total_size": 40},
        "weight_map": {
            "layer_1": "pytorch_model-00001-of-00002.bin",
            "layer_2": "pytorch_model-00001-of-00002.bin",
            "layer_3": "pytorch_model-00001-of-00002.bin",
            "layer_4": "pytorch_model-00002-of-00002.bin",
            "layer_5": "pytorch_model-00002-of-00002.bin",
        },
    }


def test_save_torch_state_dict_shared_layers_not_sharded(
    tmp_path: Path, torch_state_dict_shared_layers: dict[str, "torch.Tensor"]
) -> None:
    from safetensors.torch import load_file

    save_torch_state_dict(torch_state_dict_shared_layers, tmp_path, safe_serialization=True)
    safetensors_file = tmp_path / "model.safetensors"
    assert safetensors_file.is_file()

    # Check shared layer not duplicated in file
    state_dict = load_file(safetensors_file)
    assert "shared_1" in state_dict
    assert "shared_2" not in state_dict

    # Check shared layer info in metadata
    file_bytes = safetensors_file.read_bytes()
    metadata_str = file_bytes[
        8 : struct.unpack("<Q", file_bytes[:8])[0] + 8
    ].decode()  # TODO: next time add helper for this
    assert json.loads(metadata_str)["__metadata__"]["shared_2"] == "shared_1"


def test_save_torch_state_dict_shared_layers_sharded(
    tmp_path: Path, torch_state_dict_shared_layers: dict[str, "torch.Tensor"]
) -> None:
    from safetensors.torch import load_file

    save_torch_state_dict(torch_state_dict_shared_layers, tmp_path, max_shard_size=2, safe_serialization=True)
    index_file = tmp_path / "model.safetensors.index.json"
    assert index_file.is_file()

    # Check shared layer info in index metadata
    index = json.loads(index_file.read_text())
    assert index["metadata"]["shared_2"] == "shared_1"

    # Check shared layer not duplicated in files
    for filename in index["weight_map"].values():
        state_dict = load_file(tmp_path / filename)
        assert "shared_2" not in state_dict


def test_save_torch_state_dict_discard_selected_sharded(
    tmp_path: Path, torch_state_dict_shared_layers: dict[str, "torch.Tensor"]
) -> None:
    from safetensors.torch import load_file

    save_torch_state_dict(
        torch_state_dict_shared_layers,
        tmp_path,
        max_shard_size=2,
        safe_serialization=True,
        shared_tensors_to_discard=["shared_1"],
    )
    index_file = tmp_path / "model.safetensors.index.json"
    index = json.loads(index_file.read_text())

    assert index["metadata"]["shared_1"] == "shared_2"

    for filename in index["weight_map"].values():
        state_dict = load_file(tmp_path / filename)
        assert "shared_1" not in state_dict


def test_save_torch_state_dict_discard_selected_not_sharded(
    tmp_path: Path, torch_state_dict_shared_layers: dict[str, "torch.Tensor"]
) -> None:
    from safetensors.torch import load_file

    save_torch_state_dict(
        torch_state_dict_shared_layers,
        tmp_path,
        safe_serialization=True,
        shared_tensors_to_discard=["shared_1"],
    )
    safetensors_file = tmp_path / "model.safetensors"
    assert safetensors_file.is_file()

    # Check shared layer not duplicated in file
    state_dict = load_file(safetensors_file)
    assert "shared_1" not in state_dict
    assert "shared_2" in state_dict

    # Check shared layer info in metadata
    file_bytes = safetensors_file.read_bytes()
    metadata_str = file_bytes[
        8 : struct.unpack("<Q", file_bytes[:8])[0] + 8
    ].decode()  # TODO: next time add helper for this
    assert json.loads(metadata_str)["__metadata__"]["shared_1"] == "shared_2"


def test_split_torch_state_dict_into_shards(
    tmp_path: Path, torch_state_dict_shared_layers_tensor_subclass: dict[str, "torch.Tensor"]
):
    # the model size is 72, setting max_shard_size to 32 means we'll shard the file
    state_dict_split = split_torch_state_dict_into_shards(
        torch_state_dict_shared_layers_tensor_subclass,
        filename_pattern=constants.PYTORCH_WEIGHTS_FILE_PATTERN,
        max_shard_size=32,
    )
    assert state_dict_split.is_sharded


def test_save_torch_state_dict_custom_filename(tmp_path: Path, torch_state_dict: dict[str, "torch.Tensor"]) -> None:
    """Custom filename pattern is respected."""
    # Not sharded
    save_torch_state_dict(torch_state_dict, tmp_path, filename_pattern="model.variant{suffix}.safetensors")
    assert (tmp_path / "model.variant.safetensors").is_file()

    # Sharded
    save_torch_state_dict(
        torch_state_dict, tmp_path, filename_pattern="model.variant{suffix}.safetensors", max_shard_size=30
    )
    assert (tmp_path / "model.variant.safetensors.index.json").is_file()
    assert (tmp_path / "model.variant-00001-of-00002.safetensors").is_file()
    assert (tmp_path / "model.variant-00002-of-00002.safetensors").is_file()


def test_save_torch_state_dict_delete_existing_files(
    tmp_path: Path, torch_state_dict: dict[str, "torch.Tensor"]
) -> None:
    """Directory is cleaned before saving new files."""
    (tmp_path / "model.safetensors").touch()
    (tmp_path / "model.safetensors.index.json").touch()
    (tmp_path / "model-00001-of-00003.safetensors").touch()
    (tmp_path / "model-00002-of-00003.safetensors").touch()
    (tmp_path / "model-00003-of-00003.safetensors").touch()

    (tmp_path / "pytorch_model.bin").touch()
    (tmp_path / "pytorch_model.bin.index.json").touch()
    (tmp_path / "pytorch_model-00001-of-00003.bin").touch()
    (tmp_path / "pytorch_model-00002-of-00003.bin").touch()
    (tmp_path / "pytorch_model-00003-of-00003.bin").touch()

    save_torch_state_dict(torch_state_dict, tmp_path)
    assert (tmp_path / "model.safetensors").stat().st_size > 0  # new file

    # Previous shards have been deleted
    assert not (tmp_path / "model.safetensors.index.json").is_file()  # deleted
    assert not (tmp_path / "model-00001-of-00003.safetensors").is_file()  # deleted
    assert not (tmp_path / "model-00002-of-00003.safetensors").is_file()  # deleted
    assert not (tmp_path / "model-00003-of-00003.safetensors").is_file()  # deleted

    # But not previous pickle files (since saving as safetensors)
    assert (tmp_path / "pytorch_model.bin").is_file()  # not deleted
    assert (tmp_path / "pytorch_model.bin.index.json").is_file()
    assert (tmp_path / "pytorch_model-00001-of-00003.bin").is_file()
    assert (tmp_path / "pytorch_model-00002-of-00003.bin").is_file()
    assert (tmp_path / "pytorch_model-00003-of-00003.bin").is_file()


def test_save_torch_state_dict_not_main_process(
    tmp_path: Path,
    torch_state_dict: dict[str, "torch.Tensor"],
) -> None:
    """
    Test that previous files in the directory are not deleted when is_main_process=False.
    When is_main_process=True, previous files should be deleted,
    this is already tested in `test_save_torch_state_dict_delete_existing_files`.
    """
    # Create some .safetensors files before saving a new state dict.
    (tmp_path / "model.safetensors").touch()
    (tmp_path / "model-00001-of-00002.safetensors").touch()
    (tmp_path / "model-00002-of-00002.safetensors").touch()
    (tmp_path / "model.safetensors.index.json").touch()
    # Save with is_main_process=False
    save_torch_state_dict(torch_state_dict, tmp_path, is_main_process=False)

    # Previous files should still exist (not deleted)
    assert (tmp_path / "model.safetensors").is_file()
    assert (tmp_path / "model-00001-of-00002.safetensors").is_file()
    assert (tmp_path / "model-00002-of-00002.safetensors").is_file()
    assert (tmp_path / "model.safetensors.index.json").is_file()


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_load_state_dict_from_file(tmp_path: Path, torch_state_dict: dict[str, "torch.Tensor"]):
    """Test saving and loading a state dict with both safetensors and pickle formats."""
    import torch  # type: ignore[import]

    # Test safetensors format (default)
    save_torch_state_dict(torch_state_dict, tmp_path)
    loaded_dict = load_state_dict_from_file(tmp_path / "model.safetensors")
    assert isinstance(loaded_dict, dict)
    assert set(loaded_dict.keys()) == set(torch_state_dict.keys())
    for key in torch_state_dict:
        assert torch.equal(loaded_dict[key], torch_state_dict[key])

    # Test PyTorch pickle format
    save_torch_state_dict(torch_state_dict, tmp_path, safe_serialization=False)
    loaded_dict = load_state_dict_from_file(tmp_path / "pytorch_model.bin", safe=False)
    assert isinstance(loaded_dict, dict)
    assert set(loaded_dict.keys()) == set(torch_state_dict.keys())
    for key in torch_state_dict:
        assert torch.equal(loaded_dict[key], torch_state_dict[key])

    # A pickle checkpoint is rejected by default (`safe=True`)
    with pytest.raises(ValueError, match="Cannot load .* as safetensors"):
        load_state_dict_from_file(tmp_path / "pytorch_model.bin")


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_load_sharded_state_dict(
    tmp_path: Path,
    torch_state_dict: dict[str, "torch.Tensor"],
    dummy_model: "torch.nn.Module",
):
    """Test saving and loading a sharded state dict."""
    import torch

    save_torch_state_dict(
        torch_state_dict,
        save_directory=tmp_path,
        max_shard_size=30,  # Small size to force sharding
    )

    # Verify sharding occurred
    index_file = tmp_path / "model.safetensors.index.json"
    assert index_file.exists()

    # Load and verify content
    result = _load_sharded_checkpoint(dummy_model, tmp_path)
    assert not result.missing_keys
    assert not result.unexpected_keys

    # Verify tensor values
    loaded_state_dict = dummy_model.state_dict()
    for key in torch_state_dict:
        assert torch.equal(loaded_state_dict[key], torch_state_dict[key])


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_load_from_directory_not_sharded(
    tmp_path: Path, torch_state_dict: dict[str, "torch.Tensor"], dummy_model: "torch.nn.Module"
):
    import torch

    save_torch_state_dict(torch_state_dict, save_directory=tmp_path)

    # Verify no sharding occurred
    index_file = tmp_path / "model.safetensors.index.json"
    assert not index_file.exists()

    result = load_torch_model(dummy_model, tmp_path)

    assert not result.missing_keys
    assert not result.unexpected_keys

    loaded_state_dict = dummy_model.state_dict()
    for key in torch_state_dict:
        assert torch.equal(loaded_state_dict[key], torch_state_dict[key])


@pytest.mark.parametrize("safe_serialization", [True, False])
def test_load_state_dict_missing_file(safe_serialization):
    """Test proper error handling when file is missing."""
    with pytest.raises(FileNotFoundError, match="No checkpoint file found"):
        load_state_dict_from_file(
            "nonexistent.safetensors" if safe_serialization else "nonexistent.bin",
        )


def test_load_torch_model_directory_does_not_exist():
    """Test proper error handling when directory does not contain a valid checkpoint."""
    with pytest.raises(FileNotFoundError, match="Checkpoint path does_not_exist does not exist"):
        load_torch_model(Mock(), "does_not_exist")


def test_load_torch_model_directory_does_not_contain_checkpoint(tmp_path):
    """Test proper error handling when directory does not contain a valid checkpoint."""
    with pytest.raises(ValueError, match=r"Directory .* does not contain a valid checkpoint."):
        load_torch_model(Mock(), tmp_path)


@pytest.mark.parametrize(
    "strict",
    [
        True,
        False,
    ],
)
def test_load_sharded_model_strict_mode(tmp_path, torch_state_dict, dummy_model, strict):
    """Test loading model with strict mode behavior for both sharded and non-sharded checkpoints."""

    import torch

    # Add an extra key to the state dict
    modified_dict = {**torch_state_dict, "extra_key": torch.tensor([1.0])}

    # Save checkpoint
    save_torch_state_dict(
        modified_dict,
        save_directory=tmp_path,
        max_shard_size=30,
    )

    if strict:
        with pytest.raises(RuntimeError, match=".*Unexpected key.*"):
            result = load_torch_model(
                model=dummy_model,
                checkpoint_path=tmp_path,
                strict=strict,
            )
    else:
        result = load_torch_model(
            model=dummy_model,
            checkpoint_path=tmp_path,
            strict=strict,
        )
        assert "extra_key" in result.unexpected_keys


def test_load_torch_model_with_filename_pattern(tmp_path, torch_state_dict, dummy_model):
    """Test loading a model with a custom filename pattern."""

    import torch

    save_torch_state_dict(
        torch_state_dict,
        save_directory=tmp_path,
        filename_pattern="model.variant{suffix}.safetensors",
    )
    result = load_torch_model(
        dummy_model,
        tmp_path,
        filename_pattern="model.variant{suffix}.safetensors",
    )
    assert not result.missing_keys
    assert not result.unexpected_keys
    loaded_state_dict = dummy_model.state_dict()
    for key in torch_state_dict:
        assert torch.equal(loaded_state_dict[key], torch_state_dict[key])


@pytest.mark.parametrize(
    "filename_pattern, safe, files_exist, expected_filename_pattern",
    [
        (
            None,
            True,
            ["model.safetensors.index.json"],
            constants.SAFETENSORS_WEIGHTS_FILE_PATTERN,
        ),  # safetensors exists and safe=True -> load safetensors
        (
            None,
            False,
            ["pytorch_model.bin.index.json"],
            constants.PYTORCH_WEIGHTS_FILE_PATTERN,
        ),  # only picle file exists and safe=False -> load pickle files
        (
            None,
            False,
            ["model.safetensors.index.json", "pytorch_model.bin.index.json"],
            constants.SAFETENSORS_WEIGHTS_FILE_PATTERN,
        ),  # both exist and safe=False -> load safetensors
        (
            "model.variant{suffix}.safetensors",
            False,
            ["model.variant.safetensors.index.json", "pytorch_model.bin.index.json"],
            "model.variant{suffix}.safetensors",
        ),  # both exist and safe=False -> load safetensors
        (
            "model.variant{suffix}.bin",
            False,
            ["model.variant.safetensors.index.json", "model.variant.bin.index.json"],
            "model.variant{suffix}.bin",
        ),  # custom filename pattern and safe=False -> load custom file index
    ],
)
@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_load_torch_model_index_selection(
    tmp_path: Path,
    filename_pattern,
    safe,
    files_exist,
    expected_filename_pattern,
    mocker,
):
    """Test the logic for selecting between safetensors and pytorch index files."""
    import torch

    class SimpleModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.layer_1 = torch.nn.Parameter(torch.tensor([0.0]))

    model = SimpleModel()
    # Create specified index files
    for filename in files_exist:
        (tmp_path / filename).touch()

    # Mock _load_sharded_checkpoint to capture the safe parameter
    mock_load = mocker.patch("huggingface_hub.serialization._torch._load_sharded_checkpoint")
    load_torch_model(model, tmp_path, safe=safe, filename_pattern=filename_pattern)
    mock_load.assert_called_once()
    assert mock_load.call_args.kwargs["filename_pattern"] == expected_filename_pattern


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_load_torch_model_pickle_pattern_with_safe_true(tmp_path):
    """A pickle `filename_pattern` combined with `safe=True` is rejected instead of silently loading pickles."""
    import torch

    class SimpleModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.layer_1 = torch.nn.Parameter(torch.tensor([0.0]))

    (tmp_path / "model.variant.bin.index.json").touch()

    with pytest.raises(ValueError, match="does not describe safetensors files but `safe=True`"):
        load_torch_model(SimpleModel(), tmp_path, safe=True, filename_pattern="model.variant{suffix}.bin")


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_load_torch_model_forwards_mmap_for_single_file(tmp_path, torch_state_dict, dummy_model, mocker):
    """`mmap` used to be a silent no-op in the single-file branch."""
    save_torch_state_dict(torch_state_dict, tmp_path)
    mock_load = mocker.patch("huggingface_hub.serialization._torch.load_state_dict_from_file", return_value={})

    load_torch_model(dummy_model, tmp_path / "model.safetensors", mmap=True)

    assert mock_load.call_args.kwargs["mmap"] is True


@pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
def test_load_torch_model_safe_false_falls_back_to_pickle_with_several_safetensors(
    tmp_path, torch_state_dict, dummy_model
):
    """The `.bin` fallback must also run when the safetensors glob found several files, not just zero."""
    import torch

    save_torch_state_dict(torch_state_dict, tmp_path)
    (tmp_path / "model.fp16.safetensors").write_bytes((tmp_path / "model.safetensors").read_bytes())
    torch.save(torch_state_dict, tmp_path / "pytorch_model.bin")

    result = load_torch_model(dummy_model, tmp_path, safe=False)

    assert not result.missing_keys


class _MarkerPayload:
    """Pickle payload that touches `marker` when unpickled.

    Used to prove a checkpoint is never deserialized as pickle when it must not be: asserting that loading raised is
    not enough, since the payload runs *before* any format error is raised.
    """

    def __init__(self, marker: Path) -> None:
        self.marker = marker

    def __reduce__(self):
        return (Path.touch, (self.marker,))


def _write_pickle(path: Path, marker: Path) -> None:
    path.write_bytes(pickle.dumps(_MarkerPayload(marker)))


class TestCheckpointLoadingSecurity:
    """Regression tests for deserialization safety in checkpoint loading.

    See https://github.com/huggingface/hackerone/issues/141 for more details.

    Ensures that crafted checkpoints and index files cannot trick the loader into deserializing
    unsafe pickle payloads or accessing files outside the checkpoint directory.
    """

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    def test_pickle_payload_is_live(self, tmp_path):
        """Control: the payload below does execute when pickle loading is explicitly requested.

        `torch.load` only notices the file is not a real checkpoint *after* unpickling it, so the marker exists even
        though the call raises.
        """
        marker = tmp_path / "PWNED"
        checkpoint = tmp_path / "model.bin"
        _write_pickle(checkpoint, marker)

        with pytest.raises(RuntimeError, match="Invalid magic number"):
            load_state_dict_from_file(checkpoint, safe=False, weights_only=False)

        assert marker.exists()

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    @pytest.mark.parametrize("filename", ["model.safetensors", "model.SAFETENSORS", "model.SafeTensors"])
    def test_pickle_named_safetensors_is_not_executed(self, tmp_path, filename):
        """A pickle file named like safetensors goes to the safetensors loader, it is never deserialized."""
        marker = tmp_path / "PWNED"
        _write_pickle(tmp_path / filename, marker)

        with pytest.raises(ValueError, match="Cannot load .* as safetensors"):
            load_state_dict_from_file(tmp_path / filename)

        assert not marker.exists()

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    def test_weights_only_default_rejects_pickle_globals(self, tmp_path):
        """Without `weights_only=False`, torch's restricted unpickler refuses objects that are not tensors."""
        marker = tmp_path / "PWNED"
        checkpoint = tmp_path / "model.bin"
        _write_pickle(checkpoint, marker)

        with pytest.raises(pickle.UnpicklingError):
            load_state_dict_from_file(checkpoint, safe=False)

        assert not marker.exists()

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    @pytest.mark.parametrize("weights_only", [True, False])
    def test_old_torch_warns_that_weights_only_is_not_honored(
        self, tmp_path, torch_state_dict, mocker, caplog, weights_only
    ):
        """torch < 1.13 has no restricted unpickler, so `weights_only=True` cannot be honored: warn, don't stay silent."""
        import torch

        torch.save(torch_state_dict, tmp_path / "model.bin")
        mocker.patch.object(torch, "__version__", "1.11.0")
        mock_load = mocker.patch.object(torch, "load", return_value={})

        with caplog.at_level("WARNING"):
            load_state_dict_from_file(tmp_path / "model.bin", safe=False, weights_only=weights_only)

        assert "weights_only" not in mock_load.call_args.kwargs  # not forwarded on this torch
        assert "arbitrary code at load time" in caplog.text

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    def test_load_torch_model_does_not_execute_pickle(self, tmp_path, dummy_model):
        """Neither an explicit pickle path nor a directory picks up a pickle under `safe=True`."""
        marker = tmp_path / "PWNED"
        checkpoint = tmp_path / "pytorch_model.bin"
        _write_pickle(checkpoint, marker)

        with pytest.raises(ValueError, match="Cannot load .* as safetensors"):
            load_torch_model(dummy_model, checkpoint, safe=True)

        # In a directory, a `.bin` is simply not picked up when `safe=True`; the uppercase spelling is only matched
        # on a case-insensitive filesystem, where it goes to the safetensors loader and is rejected.
        checkpoint.rename(tmp_path / "model.SAFETENSORS")
        with pytest.raises(ValueError):
            load_torch_model(dummy_model, tmp_path, safe=True)

        assert not marker.exists()

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    def test_load_sharded_model_strict_succeeds(self, tmp_path, torch_state_dict, dummy_model):
        """`strict=True` works on a legitimate multi-shard checkpoint."""
        save_torch_state_dict(torch_state_dict, tmp_path, max_shard_size=30)
        assert (tmp_path / "model.safetensors.index.json").is_file()  # actually sharded

        result = load_torch_model(dummy_model, tmp_path, strict=True)

        assert not result.missing_keys
        assert not result.unexpected_keys

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    def test_index_cannot_misreport_the_loaded_keys(self, tmp_path, torch_state_dict, dummy_model):
        """Keys are reported from the shard contents, not from the index declaring them."""
        save_torch_state_dict(torch_state_dict, tmp_path, max_shard_size=30)
        index_file = tmp_path / "model.safetensors.index.json"
        index = json.loads(index_file.read_text())
        weight_map = index["weight_map"]

        # Drop an entry whose shard holds other tensors: that shard is still listed, so the tensor is still loaded.
        shards = list(weight_map.values())
        dropped_key = next(key for key, shard in weight_map.items() if shards.count(shard) > 1)
        del weight_map[dropped_key]
        # And declare a tensor that no shard contains.
        weight_map["ghost"] = shards[0]
        index_file.write_text(json.dumps(index))

        result = load_torch_model(dummy_model, tmp_path)

        assert dropped_key not in result.missing_keys  # it was loaded from the shard all along
        assert "ghost" not in result.unexpected_keys  # and was never loaded

        # And the index cannot fail `strict=True` over a tensor no shard ever held either.
        result = load_torch_model(dummy_model, tmp_path, strict=True)
        assert not result.missing_keys
        assert not result.unexpected_keys

    @pytest.mark.skipif(not is_torch_available(), reason="Test requires torch")
    def test_load_torch_model_safe_false_loads_safetensors(self, tmp_path, torch_state_dict, dummy_model):
        """`safe=False` means "fall back to pickle", not "pickle first"."""
        save_torch_state_dict(torch_state_dict, tmp_path)
        assert (tmp_path / "model.safetensors").is_file()

        result = load_torch_model(dummy_model, tmp_path, safe=False)

        assert not result.missing_keys

    @pytest.mark.parametrize("index", [None, [1, 2], {"foo": "bar"}, {"weight_map": [1, 2]}, {"weight_map": {"a": 1}}])
    def test_malformed_index_is_rejected(self, tmp_path, index):
        """A malformed index raises a clear `ValueError` instead of a raw traceback."""
        (tmp_path / "model.safetensors.index.json").write_text(json.dumps(index))

        with pytest.raises(ValueError, match="Invalid index file"):
            load_torch_model(Mock(), tmp_path)

    def test_safetensors_index_rejects_bin_shard(self, tmp_path):
        """A safetensors index file referencing a .bin shard must be rejected."""
        index = {
            "metadata": {"total_size": 100},
            "weight_map": {
                "layer_1": "model-00001-of-00001.bin",
            },
        }
        (tmp_path / "model.safetensors.index.json").write_text(json.dumps(index))
        (tmp_path / "model-00001-of-00001.bin").touch()

        with pytest.raises(ValueError, match="Invalid shard filename.*Expected '.safetensors' extension"):
            load_torch_model(Mock(), tmp_path)

    @pytest.mark.parametrize(
        ("filename", "expected"),
        [
            ("model.safetensors", True),
            ("model-00001-of-00002.safetensors", True),
            (".safetensors", True),  # extension-only name: `Path(...).suffix` would return ""
            ("sub/.safetensors", True),
            (Path("model.safetensors"), True),
            # Windows and macOS resolve filenames case-insensitively, so uppercase variants must be recognized
            ("model.SAFETENSORS", True),
            ("model.SafeTensors", True),
            ("MODEL.SAFETENSORS", True),
            ("model.bin", False),
            ("model.safetensors.index.json", False),
            ("safetensors", False),
        ],
    )
    def test_is_safetensors(self, filename, expected):
        assert _is_safetensors(filename) is expected

    def test_safetensors_index_rejects_path_traversal(self, tmp_path):
        """A shard filename with '..' path traversal must be rejected."""
        index = {
            "metadata": {"total_size": 100},
            "weight_map": {
                "layer_1": "../malicious.safetensors",
            },
        }
        (tmp_path / "model.safetensors.index.json").write_text(json.dumps(index))

        with pytest.raises(ValueError, match="Invalid shard filename.*without '..' components"):
            load_torch_model(Mock(), tmp_path)

    @pytest.mark.parametrize(
        "malicious_path",
        [
            "/tmp/malicious.safetensors",  # POSIX absolute
            "\\malicious.safetensors",  # Windows rooted, no drive (resolves to C:\malicious on Windows)
            "C:malicious.safetensors",  # Windows drive-only (relative to CWD of drive C)
            "C:\\malicious.safetensors",  # Windows drive-absolute
            "\\\\server\\share\\malicious.safetensors",  # Windows UNC
            "..\\malicious.safetensors",  # Windows-style traversal (backslash as separator)
        ],
    )
    def test_safetensors_index_rejects_absolute_path(self, tmp_path, malicious_path):
        """A shard filename with an absolute path must be rejected on every host OS."""
        index = {
            "metadata": {"total_size": 100},
            "weight_map": {
                "layer_1": malicious_path,
            },
        }
        (tmp_path / "model.safetensors.index.json").write_text(json.dumps(index))

        with pytest.raises(ValueError, match="Invalid shard filename.*without '..' components"):
            load_torch_model(Mock(), tmp_path)
