import sys
import time
from io import SEEK_END
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from huggingface_hub import CommitOperationAdd, HfApi, hf_hub_download
from huggingface_hub._commit_scheduler import CommitScheduler, PartialFileIO

from .testing_utils import repo_name


class TestCommitScheduler:
    @pytest.fixture(autouse=True)
    def _setup(self, api: HfApi):
        self.api = api
        self.repo_name = repo_name()
        yield
        try:  # try stopping scheduler (if exists)
            self.scheduler.stop()
        except AttributeError:
            pass

        self.api.delete_repo(self.repo_name, missing_ok=True)

    def test_mocked_push_to_hub(self, mocker, tmp_path: Path) -> None:
        push_to_hub_mock: MagicMock = mocker.patch("huggingface_hub._commit_scheduler.CommitScheduler.push_to_hub")
        self.scheduler = CommitScheduler(
            folder_path=tmp_path,
            repo_id=self.repo_name,
            every=1 / 60 / 10,  # every 0.1s
            hf_api=self.api,
        )
        time.sleep(0.5)

        # Triggered at least twice (at 0.0s and then 0.1s, 0.2s,...)
        assert len(push_to_hub_mock.call_args_list) > 2

        # Can get the last upload result
        assert self.scheduler.last_future.result() == push_to_hub_mock.return_value

    def test_invalid_folder_path_is_a_file(self, tmp_path: Path) -> None:
        """Test cannot scheduler upload of a single file."""
        file_path = tmp_path / "file.txt"
        file_path.write_text("something")

        with pytest.raises(ValueError):
            CommitScheduler(folder_path=file_path, repo_id=self.repo_name, hf_api=self.api)

    def test_missing_folder_is_created(self, tmp_path: Path) -> None:
        folder_path = tmp_path / "folder" / "subfolder"
        self.scheduler = CommitScheduler(folder_path=folder_path, repo_id=self.repo_name, hf_api=self.api)
        assert folder_path.is_dir()

    @pytest.mark.skipif(
        sys.platform == "win32" and sys.version_info >= (3, 14),
        reason="Flaky on Windows Python 3.14 due to file lock on lfs.bin",
    )
    def test_sync_local_folder(self, tmp_path: Path) -> None:
        """Test sync local folder to remote repo."""
        watched_folder = tmp_path / "watched_folder"
        hub_cache = tmp_path / "hub"  # to download hub files

        file_path = watched_folder / "file.txt"
        lfs_path = watched_folder / "lfs.bin"

        self.scheduler = CommitScheduler(
            folder_path=watched_folder,
            repo_id=self.repo_name,
            every=1 / 60,  # every 1s
            hf_api=self.api,
        )

        # 1 push to hub triggered (empty commit not pushed)
        time.sleep(0.5)

        # write content to files
        with file_path.open("a") as f:
            f.write("first line\n")
        with lfs_path.open("a") as f:
            f.write("binary content")

        # 2 push to hub triggered (1 commit + 1 ignored)
        time.sleep(2)
        self.scheduler.last_future.result()

        # new content in file
        with file_path.open("a") as f:
            f.write("second line\n")

        # 1 push to hub triggered (1 commit)
        time.sleep(1)
        self.scheduler.last_future.result()

        with lfs_path.open("a") as f:
            f.write(" updated")

        # 5 push to hub triggered (1 commit)
        time.sleep(5)  # wait for every threads/uploads to complete
        self.scheduler.stop()
        self.scheduler.last_future.result()

        # 4 commits expected (initial commit + 3 push to hub)
        repo_id = self.scheduler.repo_id
        commits = self.api.list_repo_commits(repo_id)
        assert len(commits) == 4
        push_1 = commits[2].commit_id  # sorted by last first
        push_2 = commits[1].commit_id
        push_3 = commits[0].commit_id

        def _download(filename: str, revision: str) -> Path:
            return Path(hf_hub_download(repo_id=repo_id, filename=filename, cache_dir=hub_cache, revision=revision))

        # Check file.txt consistency
        file_push1 = _download(filename="file.txt", revision=push_1)
        file_push2 = _download(filename="file.txt", revision=push_2)
        file_push3 = _download(filename="file.txt", revision=push_3)

        assert file_push1.read_text() == "first line\n"
        assert file_push2.read_text() == "first line\nsecond line\n"
        assert file_push3.read_text() == "first line\nsecond line\n"

        # Check lfs.bin consistency
        lfs_push1 = _download(filename="lfs.bin", revision=push_1)
        lfs_push2 = _download(filename="lfs.bin", revision=push_2)
        lfs_push3 = _download(filename="lfs.bin", revision=push_3)

        assert lfs_push1.read_text() == "binary content"
        assert lfs_push2.read_text() == "binary content"
        assert lfs_push3.read_text() == "binary content updated"

    def test_sync_and_squash_history(self, tmp_path: Path) -> None:
        """Test squash history when pushing to the Hub."""
        watched_folder = tmp_path / "watched_folder"
        watched_folder.mkdir(exist_ok=True, parents=True)
        file_path = watched_folder / "file.txt"
        with file_path.open("a") as f:
            f.write("first line\n")

        self.scheduler = CommitScheduler(
            folder_path=watched_folder,
            repo_id=self.repo_name,
            every=1 / 60 / 10,  # every 0.1s
            hf_api=self.api,
            squash_history=True,
        )

        # At least 1 push to hub triggered
        time.sleep(0.5)
        self.scheduler.stop()
        self.scheduler.last_future.result()

        # Branch history has been squashed
        commits = self.api.list_repo_commits(repo_id=self.scheduler.repo_id)
        assert len(commits) == 1
        assert commits[0].title == "Super-squash branch 'main' using huggingface_hub"

    def test_context_manager(self, tmp_path: Path) -> None:
        watched_folder = tmp_path / "watched_folder"
        watched_folder.mkdir(exist_ok=True, parents=True)
        file_path = watched_folder / "file.txt"

        with CommitScheduler(
            folder_path=watched_folder,
            repo_id=self.repo_name,
            every=5,  # every 5min
            hf_api=self.api,
        ) as scheduler:
            with file_path.open("w") as f:
                f.write("first line\n")

        assert "file.txt" in self.api.list_repo_files(scheduler.repo_id)
        assert scheduler._CommitScheduler__stopped  # means the scheduler has been stopped when exiting the context


class TestPartialFileIO:
    """Test PartialFileIO object."""

    @pytest.fixture(autouse=True)
    def _setup(self, tmp_path) -> None:
        """Set up a test file."""
        self.file_path = tmp_path / "file.txt"
        self.file_path.write_text("123456789")  # file size: 9 bytes

    def test_read_partial_file_twice(self) -> None:
        file = PartialFileIO(self.file_path, size_limit=5)
        assert file.read() == b"12345"
        assert file.read() == b""  # End of file

    def test_read_partial_file_by_chunks(self) -> None:
        file = PartialFileIO(self.file_path, size_limit=5)
        assert file.read(2) == b"12"
        assert file.read(2) == b"34"
        assert file.read(2) == b"5"
        assert file.read(2) == b""

    def test_read_partial_file_too_much(self) -> None:
        file = PartialFileIO(self.file_path, size_limit=5)
        assert file.read(20) == b"12345"

    def test_partial_file_len(self) -> None:
        """Useful for httpx2 internally."""
        file = PartialFileIO(self.file_path, size_limit=5)
        assert len(file) == 5

        file = PartialFileIO(self.file_path, size_limit=50)
        assert len(file) == 9

    def test_partial_file_fileno(self) -> None:
        """We explicitly do not implement fileno() to avoid misuse.

        httpx2 tries to use it to check file size which we don't want for PartialFileIO.
        """
        file = PartialFileIO(self.file_path, size_limit=5)
        with pytest.raises(AttributeError):
            file.fileno()

    def test_partial_file_seek_and_tell(self) -> None:
        file = PartialFileIO(self.file_path, size_limit=5)

        assert file.tell() == 0

        file.read(2)
        assert file.tell() == 2

        file.seek(0)
        assert file.tell() == 0

        file.seek(2)
        assert file.tell() == 2

        file.seek(50)
        assert file.tell() == 5

        file.seek(-3, SEEK_END)
        assert file.tell() == 2  # 5-3

    def test_methods_not_implemented(self) -> None:
        """Test `PartialFileIO` only implements a subset of the `io` interface. This is on-purpose to avoid misuse."""
        file = PartialFileIO(self.file_path, size_limit=5)

        with pytest.raises(NotImplementedError):
            file.readline()

        with pytest.raises(NotImplementedError):
            file.write(b"123")

    def test_append_to_file_then_read(self) -> None:
        file = PartialFileIO(self.file_path, size_limit=9)

        with self.file_path.open("ab") as f:
            f.write(b"abcdef")

        # Output is truncated even if new content appended to the wrapped file
        assert file.read() == b"123456789"

    def test_high_size_limit(self) -> None:
        file = PartialFileIO(self.file_path, size_limit=20)
        with self.file_path.open("ab") as f:
            f.write(b"abcdef")

        # File size limit is truncated to the actual file size at instance creation (not on the fly)
        assert len(file) == 9
        assert file._size_limit == 9

    def test_with_commit_operation_add(self) -> None:
        # Truncated file
        op_truncated = CommitOperationAdd(
            path_or_fileobj=PartialFileIO(self.file_path, size_limit=5), path_in_repo="file.txt"
        )
        assert op_truncated.upload_info.size == 5
        assert op_truncated.upload_info.sample == b"12345"

        with op_truncated.as_file() as f:
            assert f.read() == b"12345"

        # Full file
        op_full = CommitOperationAdd(
            path_or_fileobj=PartialFileIO(self.file_path, size_limit=9), path_in_repo="file.txt"
        )
        assert op_full.upload_info.size == 9
        assert op_full.upload_info.sample == b"123456789"

        with op_full.as_file() as f:
            assert f.read() == b"123456789"

        # Truncated file has a different hash than the full file
        assert op_truncated.upload_info.sha256 != op_full.upload_info.sha256
