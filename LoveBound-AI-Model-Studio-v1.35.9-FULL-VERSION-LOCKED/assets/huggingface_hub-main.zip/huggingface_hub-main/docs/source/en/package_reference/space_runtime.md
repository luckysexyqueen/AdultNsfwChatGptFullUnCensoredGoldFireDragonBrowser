<!--⚠️ Note that this file is in Markdown but contains specific syntax for our doc-builder (similar to MDX) that may not be
rendered properly in your Markdown viewer.
-->

# Managing your Space runtime

Check the [`HfApi`] documentation page for the reference of methods to manage your Space on the Hub.

- Fetch current runtime: [`get_space_runtime`]
- Fetch build or run logs: [`fetch_space_logs`]
- Manage secrets: [`add_space_secret`] and [`delete_space_secret`]
- Manage hardware: [`request_space_hardware`]
- Manage state: [`pause_space`], [`restart_space`], [`set_space_sleep_time`]
- Wait until Space is ready: [`wait_for_space`]
- Check your ZeroGPU quota: [`get_zero_gpu_quota`]

## Data structures

### SpaceRuntime

[[autodoc]] SpaceRuntime

### SpaceHardware

[[autodoc]] SpaceHardware

### SpaceStage

[[autodoc]] SpaceStage

### SpaceStorage

[[autodoc]] SpaceStorage

### SpaceVariable

[[autodoc]] SpaceVariable

### SpaceTemplate

[[autodoc]] SpaceTemplate

### ZeroGpuQuota

[[autodoc]] ZeroGpuQuota
